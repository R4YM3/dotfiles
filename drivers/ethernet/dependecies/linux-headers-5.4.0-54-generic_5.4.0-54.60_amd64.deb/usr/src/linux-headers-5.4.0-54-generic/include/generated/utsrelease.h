#define UTS_RELEASE "5.4.0-54-generic"
#define UTS_UBUNTU_RELEASE_ABI 54
