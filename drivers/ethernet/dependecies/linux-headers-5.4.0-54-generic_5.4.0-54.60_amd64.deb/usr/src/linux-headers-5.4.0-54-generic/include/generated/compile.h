/* This file is auto generated, version 60-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#60-Ubuntu SMP Fri Nov 6 10:37:59 UTC 2020"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-amd64-024"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-17ubuntu1~20.04)"
