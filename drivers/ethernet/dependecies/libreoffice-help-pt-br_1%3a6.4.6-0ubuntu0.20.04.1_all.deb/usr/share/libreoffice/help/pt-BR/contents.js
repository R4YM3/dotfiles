document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros e criação de scripts</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/main0601.html?DbPAR=BASIC">Ajuda do LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programar com o LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glossário do LibreOffice Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01010210.html?DbPAR=BASIC">Fundamentos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01020000.html?DbPAR=BASIC">Sintaxe</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01050000.html?DbPAR=BASIC">IDE Basic do LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01030100.html?DbPAR=BASIC">Visão geral do IDE</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01030200.html?DbPAR=BASIC">O editor Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01050100.html?DbPAR=BASIC">Janela de inspeção</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barra de macros</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Suporte para macros VBA</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Referência de comandos</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01020300.html?DbPAR=BASIC">Utilizar procedimentos e funções</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliotecas, módulos e diálogos</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funções, instruções e operadores</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funções de E/S de tela</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020000.html?DbPAR=BASIC">Funções de E/S de arquivos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030000.html?DbPAR=BASIC">Funções de data e hora</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funções de tratamento de erros</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060000.html?DbPAR=BASIC">Operadores lógicos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070000.html?DbPAR=BASIC">Operadores matemáticos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funções numéricas</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090000.html?DbPAR=BASIC">Controlar a execução do programa</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variáveis</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03040000.html?DbPAR=BASIC">Constantes do BASIC</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03110000.html?DbPAR=BASIC">Operadores de comparação</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120000.html?DbPAR=BASIC">Strings</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Objetos UNO</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Funções VBA exclusivas</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130000.html?DbPAR=BASIC">Outros comandos</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Lista alfabética de funções, instruções e operadores</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080601.html?DbPAR=BASIC">Função Abs</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operador AND</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104200.html?DbPAR=BASIC">Função Array</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120101.html?DbPAR=BASIC">Função Asc</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120111.html?DbPAR=BASIC">Função AscW</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080101.html?DbPAR=BASIC">Função Atn</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130100.html?DbPAR=BASIC">Instrução Beep</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010301.html?DbPAR=BASIC">Função Blue</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100100.html?DbPAR=BASIC">Função CBool</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120105.html?DbPAR=BASIC">Função CByte</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100050.html?DbPAR=BASIC">Função CCur</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030116.html?DbPAR=BASIC">Função CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030115.html?DbPAR=BASIC">Função CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030114.html?DbPAR=BASIC">Função CDateFromUnoTime</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030113.html?DbPAR=BASIC">Função CDateToUnoTime</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030112.html?DbPAR=BASIC">Função CDateFromUnoDate</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030111.html?DbPAR=BASIC">Função CDateToUnoDate</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030108.html?DbPAR=BASIC">Função CDateFromlso</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030107.html?DbPAR=BASIC">Função CDateToIso</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100300.html?DbPAR=BASIC">Função CDate</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100400.html?DbPAR=BASIC">Função CDbl</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100060.html?DbPAR=BASIC">Função CDec</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100500.html?DbPAR=BASIC">Função CInt</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100600.html?DbPAR=BASIC">Função Clng</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100900.html?DbPAR=BASIC">Função Csng</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101000.html?DbPAR=BASIC">Função Cstr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090401.html?DbPAR=BASIC">Instrução Call</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020401.html?DbPAR=BASIC">Instrução ChDir</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020402.html?DbPAR=BASIC">Instrução ChDrive</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090402.html?DbPAR=BASIC">Função Choose</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120102.html?DbPAR=BASIC">Função Chr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120112.html?DbPAR=BASIC">Função ChrW [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instrução Close</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadores de comparação</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100700.html?DbPAR=BASIC">Instrução Const</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120313.html?DbPAR=BASIC">Função ConvertFromURL</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120312.html?DbPAR=BASIC">Função ConvertToURL</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080102.html?DbPAR=BASIC">Função Cos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132400.html?DbPAR=BASIC">Função CreateObject</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131800.html?DbPAR=BASIC">Função CreateUnoDialog</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132000.html?DbPAR=BASIC">Função CreateUnoListener</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131600.html?DbPAR=BASIC">Função CreateUnoService</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131500.html?DbPAR=BASIC">Função CreateUnoStruct</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132300.html?DbPAR=BASIC">Função CreateUnoValue</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020403.html?DbPAR=BASIC">Função CurDir</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100070.html?DbPAR=BASIC">Função CVar</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03100080.html?DbPAR=BASIC">Função CVErr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030110.html?DbPAR=BASIC">Função DateAdd</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030120.html?DbPAR=BASIC">Função DateDiff</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030130.html?DbPAR=BASIC">Função DatePart</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030101.html?DbPAR=BASIC">Função DateSerial</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030102.html?DbPAR=BASIC">Função DateValue</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030301.html?DbPAR=BASIC">Instrução Date</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030103.html?DbPAR=BASIC">Função Day</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140000.html?DbPAR=BASIC">Função DDB [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090403.html?DbPAR=BASIC">Instrução Declare</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101100.html?DbPAR=BASIC">Instrução DefBool</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101300.html?DbPAR=BASIC">Instrução DefDate</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101400.html?DbPAR=BASIC">Instrução DefDbl</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101500.html?DbPAR=BASIC">Instrução DefInt</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101600.html?DbPAR=BASIC">Instrução DefLng</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03101700.html?DbPAR=BASIC">Instrução DefObj</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102000.html?DbPAR=BASIC">Instrução DefVar</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104300.html?DbPAR=BASIC">Função DimArray</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102100.html?DbPAR=BASIC">Instrução Dim</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020404.html?DbPAR=BASIC">Função Dir</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090201.html?DbPAR=BASIC">Instrução Do...Loop</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03110100.html?DbPAR=BASIC">Operadores de comparação</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090404.html?DbPAR=BASIC">Instrução End</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/enum.html?DbPAR=BASIC">Instrução Enum</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130800.html?DbPAR=BASIC">Função Environ</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020301.html?DbPAR=BASIC">Função Eof</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104600.html?DbPAR=BASIC">Função EqualUnoObjects</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operador Eqv</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050100.html?DbPAR=BASIC">Função Erl</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050200.html?DbPAR=BASIC">Função Err</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050300.html?DbPAR=BASIC">Função Error</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050000.html?DbPAR=BASIC">Funções de tratamento de erros</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090412.html?DbPAR=BASIC">Instrução Exit</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080201.html?DbPAR=BASIC">Função Exp</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020405.html?DbPAR=BASIC">Função FileAttr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020406.html?DbPAR=BASIC">Instrução FileCopy</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020407.html?DbPAR=BASIC">Função FileDateTime</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020415.html?DbPAR=BASIC">Função FileExists</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020408.html?DbPAR=BASIC">Função FileLen</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103800.html?DbPAR=BASIC">Função FindObject</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103900.html?DbPAR=BASIC">Função FindPropertyObject</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080501.html?DbPAR=BASIC">Função Fix</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090202.html?DbPAR=BASIC">Instrução For...Next</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120301.html?DbPAR=BASIC">Função Format</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03150000.html?DbPAR=BASIC">Função FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03170010.html?DbPAR=BASIC">Função FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080503.html?DbPAR=BASIC">Função Frac</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020102.html?DbPAR=BASIC">Função FreeFile</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090405.html?DbPAR=BASIC">Função FreeLibrary</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090406.html?DbPAR=BASIC">Instrução Function</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090400.html?DbPAR=BASIC">Instruções adicionais</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140001.html?DbPAR=BASIC">Função FV [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080300.html?DbPAR=BASIC">Gerar números aleatórios</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020409.html?DbPAR=BASIC">Função GetAttr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132500.html?DbPAR=BASIC">Função GetDefaultContext</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132100.html?DbPAR=BASIC">Função GetGuiType</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131700.html?DbPAR=BASIC">Função GetProcessServiceManager</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Função GetPathSeparator</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131000.html?DbPAR=BASIC">Função GetSolarVersion</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130700.html?DbPAR=BASIC">Função GetSystemTicks</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020201.html?DbPAR=BASIC">Instrução Get</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090301.html?DbPAR=BASIC">Instrução GoSub...Return</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090302.html?DbPAR=BASIC">Instrução GoTo</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010302.html?DbPAR=BASIC">Função Green</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104400.html?DbPAR=BASIC">Função HasUnoInterfaces</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080801.html?DbPAR=BASIC">Função Hex</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030201.html?DbPAR=BASIC">Função Hour</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090103.html?DbPAR=BASIC">Instrução IIf</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090101.html?DbPAR=BASIC">Instrução If...Then...Else</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operador Imp</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120401.html?DbPAR=BASIC">Função InStr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120411.html?DbPAR=BASIC">Função InStrRev [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03160000.html?DbPAR=BASIC">Função Input [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010201.html?DbPAR=BASIC">Função InputBox</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020202.html?DbPAR=BASIC">Instrução Input#</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080502.html?DbPAR=BASIC">Função Int</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140002.html?DbPAR=BASIC">Função IPmt [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140003.html?DbPAR=BASIC">Função IRR [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102200.html?DbPAR=BASIC">Função IsArray</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102300.html?DbPAR=BASIC">Função IsDate</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102400.html?DbPAR=BASIC">Função IsEmpty</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104000.html?DbPAR=BASIC">Função IsMissing</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102600.html?DbPAR=BASIC">Função IsNull</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102700.html?DbPAR=BASIC">Função IsNumeric</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102800.html?DbPAR=BASIC">Função IsObject</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104500.html?DbPAR=BASIC">Função IsUnoStruct</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120315.html?DbPAR=BASIC">Função Join</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020410.html?DbPAR=BASIC">Instrução Kill</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102900.html?DbPAR=BASIC">Função LBound</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120302.html?DbPAR=BASIC">Função LCase</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120304.html?DbPAR=BASIC">Instrução LSet</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120305.html?DbPAR=BASIC">Função LTrim</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120303.html?DbPAR=BASIC">Função Left</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120402.html?DbPAR=BASIC">Função Len</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103100.html?DbPAR=BASIC">Instrução Let</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020203.html?DbPAR=BASIC">Instrução Line Input#</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020302.html?DbPAR=BASIC">Função Loc</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020303.html?DbPAR=BASIC">Função Lof</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080202.html?DbPAR=BASIC">Função Log</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120306.html?DbPAR=BASIC">Instrução Mid Function, Mid</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030202.html?DbPAR=BASIC">Função Minute</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140004.html?DbPAR=BASIC">Função MIRR [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020411.html?DbPAR=BASIC">Instrução MkDir</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operador Mod</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030104.html?DbPAR=BASIC">Função Month</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03150002.html?DbPAR=BASIC">Função MonthName [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010102.html?DbPAR=BASIC">Função MsgBox</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010101.html?DbPAR=BASIC">Instrução MsgBox</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020412.html?DbPAR=BASIC">Instrução Name</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operador Not</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030203.html?DbPAR=BASIC">Função Now</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140005.html?DbPAR=BASIC">Função NPer [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140006.html?DbPAR=BASIC">Função NPV [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080000.html?DbPAR=BASIC">Funções numéricas</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080802.html?DbPAR=BASIC">Função Oct</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03050500.html?DbPAR=BASIC">Instrução On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090303.html?DbPAR=BASIC">Instrução On...GoSub Statement; On...GoTo</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instrução Open</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103200.html?DbPAR=BASIC">Instrução Option Base</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103300.html?DbPAR=BASIC">Instrução Option Explicit</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103350.html?DbPAR=BASIC">Instrução Option VBASupport</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03104100.html?DbPAR=BASIC">Opcional (na instrução StatEment)</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operador Or</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/partition.html?DbPAR=BASIC">Função Partition</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140007.html?DbPAR=BASIC">Função Pmt [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140008.html?DbPAR=BASIC">Função PPmt [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140009.html?DbPAR=BASIC">Função PV [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010103.html?DbPAR=BASIC">Instrução Print</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103400.html?DbPAR=BASIC">Instrução Public</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020204.html?DbPAR=BASIC">Instrução Put</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010304.html?DbPAR=BASIC">Função QBColor</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140010.html?DbPAR=BASIC">Função Rate [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010305.html?DbPAR=BASIC">Função RGB</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120308.html?DbPAR=BASIC">Instrução RSet</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120309.html?DbPAR=BASIC">Função RTrim</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080301.html?DbPAR=BASIC">Instrução Randomize</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03102101.html?DbPAR=BASIC">Instrução ReDim</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03010303.html?DbPAR=BASIC">Função Red</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090407.html?DbPAR=BASIC">Instrução Rem</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/replace.html?DbPAR=BASIC">Função Replace</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020104.html?DbPAR=BASIC">Instrução Reset</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120307.html?DbPAR=BASIC">Função Right</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020413.html?DbPAR=BASIC">Instrução RmDir</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080302.html?DbPAR=BASIC">Função Rnd</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03170000.html?DbPAR=BASIC">Função Round [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030204.html?DbPAR=BASIC">Função Second</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020304.html?DbPAR=BASIC">Função Seek</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020305.html?DbPAR=BASIC">Instrução Seek</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090102.html?DbPAR=BASIC">Instrução Select...Case</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020414.html?DbPAR=BASIC">Instrução SetAttr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103700.html?DbPAR=BASIC">Instrução Set</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080701.html?DbPAR=BASIC">Função Sgn</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130500.html?DbPAR=BASIC">Função Shell</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080103.html?DbPAR=BASIC">Função Sin</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140011.html?DbPAR=BASIC">Função SLN [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120201.html?DbPAR=BASIC">Função Space e Spc</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120201.html?DbPAR=BASIC">Função Space e Spc</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120314.html?DbPAR=BASIC">Função Split</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080401.html?DbPAR=BASIC">Função Sqr</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080400.html?DbPAR=BASIC">Cálculo de raiz quadrada</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Objeto StarDesktop</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103500.html?DbPAR=BASIC">Instrução Static</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090408.html?DbPAR=BASIC">Instrução Stop</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120403.html?DbPAR=BASIC">Função StrComp</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120103.html?DbPAR=BASIC">Função Str</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120412.html?DbPAR=BASIC">Função StrReverse [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120202.html?DbPAR=BASIC">Função String</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090409.html?DbPAR=BASIC">Instrução Sub</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090410.html?DbPAR=BASIC">Função Switch</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03140012.html?DbPAR=BASIC">Função SYD [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080104.html?DbPAR=BASIC">Função Tan</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objeto ThisComponent</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030205.html?DbPAR=BASIC">Função TimeSerial</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030206.html?DbPAR=BASIC">Função TimeValue</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030302.html?DbPAR=BASIC">Instrução Time</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030303.html?DbPAR=BASIC">Função Timer</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03080100.html?DbPAR=BASIC">Funções trigonométricas</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120311.html?DbPAR=BASIC">Função Trim</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131300.html?DbPAR=BASIC">Função TwipsPerPixelX</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03131400.html?DbPAR=BASIC">Função TwipsPerPixelY</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090413.html?DbPAR=BASIC">Instrução Type</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103600.html?DbPAR=BASIC">Função TypeName Function; VarType</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03103000.html?DbPAR=BASIC">Função UBound</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120310.html?DbPAR=BASIC">Função UCase</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03120104.html?DbPAR=BASIC">Função Val</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130600.html?DbPAR=BASIC">Instrução Wait</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03130610.html?DbPAR=BASIC">Instrução WaitUntil</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030105.html?DbPAR=BASIC">Função WeekDay</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03150001.html?DbPAR=BASIC">Função WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090203.html?DbPAR=BASIC">Instrução While...Wend</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03090411.html?DbPAR=BASIC">Instrução With</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03020205.html?DbPAR=BASIC">Instrução Write</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operador XOR</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03030106.html?DbPAR=BASIC">Função Year</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operador "-"</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operador "*"</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operador "+"</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operador "/"</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operador "^"</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Bibliotecas avançadas em BASIC</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Biblioteca TOOLS</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Biblioteca DEPOT</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Biblioteca EURO</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Biblioteca FORMWIZARD</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Biblioteca GIMMICKS</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Biblioteca SCHEDULE</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Biblioteca SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Biblioteca TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guias</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/macro_recording.html?DbPAR=BASIC">Gravar uma macro</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Alterar as propriedades de controles no editor de diálogos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Criar controles no editor de diálogos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Exemplos de programação para controles no editor de diálogos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Abrir uma caixa de diálogo com Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Criar um diálogo Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01030400.html?DbPAR=BASIC">Organizar bibliotecas e módulos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01020100.html?DbPAR=BASIC">Utilizar variáveis</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01020200.html?DbPAR=BASIC">Utilizar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01030300.html?DbPAR=BASIC">Depurar um Programa Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/shared/01040000.html?DbPAR=BASIC">Macros acionadas por eventos</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Exemplos de programação em Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Do Basic para o Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Ajuda para scripts em Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/main0000.html?DbPAR=BASIC">Scripts em Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE para Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organização de scripts Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_shell.html?DbPAR=BASIC">Interpretador interativo do Python</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programar com Python</label><ul>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programar com Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_examples.html?DbPAR=BASIC">Exemplos em Python</a></li>\
    <li><a target="_top" href="pt-BR/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Do Python ao Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Planilhas (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/main0000.html?DbPAR=CALC">Bem-vindo à Ajuda do LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0503.html?DbPAR=CALC">Recursos do LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/keyboard.html?DbPAR=CALC">Teclas de atalho (acessibilidade do LibreOffice Calc)</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/04/01020000.html?DbPAR=CALC">Teclas de atalho para planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/05/02140000.html?DbPAR=CALC">Códigos de erro no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060112.html?DbPAR=CALC">Suplemento (add-in) para programação no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/main.html?DbPAR=CALC">Instruções para a utilização do LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menus</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/main0100.html?DbPAR=CALC">Menus</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0101.html?DbPAR=CALC">Arquivo</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0102.html?DbPAR=CALC">Editar</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0103.html?DbPAR=CALC">Exibir</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0104.html?DbPAR=CALC">Inserir</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0105.html?DbPAR=CALC">Formatar</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0116.html?DbPAR=CALC">Planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0112.html?DbPAR=CALC">Dados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0106.html?DbPAR=CALC">Ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0107.html?DbPAR=CALC">Janela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0108.html?DbPAR=CALC">Ajuda</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/main0200.html?DbPAR=CALC">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0202.html?DbPAR=CALC">Barra Formatação</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0203.html?DbPAR=CALC">Barra Propriedades do objeto de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0205.html?DbPAR=CALC">Barra Formatação de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0206.html?DbPAR=CALC">Barra Fórmula</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0208.html?DbPAR=CALC">Barra de status</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0210.html?DbPAR=CALC">Barra Visualização de impressão</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0214.html?DbPAR=CALC">Barra de figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/main0218.html?DbPAR=CALC">Barra Ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0201.html?DbPAR=CALC">Barra Padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0212.html?DbPAR=CALC">Barra Dados da tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0213.html?DbPAR=CALC">Barra de ferramentas Formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0214.html?DbPAR=CALC">Barra Design de consulta</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0226.html?DbPAR=CALC">Barra de ferramentas Design de formulário</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Tipo de funções e operadores</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060000.html?DbPAR=CALC">Assistente de funções</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060100.html?DbPAR=CALC">Funções por categoria</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060107.html?DbPAR=CALC">Funções de matriz</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060120.html?DbPAR=CALC">Funções de operações de bits</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060101.html?DbPAR=CALC">Funções de banco de dados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060102.html?DbPAR=CALC">Funções de data e hora</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060103.html?DbPAR=CALC">Funções financeiras - Parte 1</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060119.html?DbPAR=CALC">Funções financeiras - Parte 2</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060118.html?DbPAR=CALC">Funções financeiras - Parte 3</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060104.html?DbPAR=CALC">Funções de informação</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060105.html?DbPAR=CALC">Funções lógicas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060106.html?DbPAR=CALC">Funções matemáticas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060108.html?DbPAR=CALC">Funções estatísticas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060181.html?DbPAR=CALC">Funções estatísticas - Parte 1</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060182.html?DbPAR=CALC">Funções estatísticas - Parte 2</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060183.html?DbPAR=CALC">Funções estatísticas - Parte 3</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060184.html?DbPAR=CALC">Funções estatísticas - Parte 4</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060185.html?DbPAR=CALC">Funções estatísticas - Parte 5</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060109.html?DbPAR=CALC">Funções de planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060110.html?DbPAR=CALC">Funções de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060111.html?DbPAR=CALC">Funções de suplemento (add-in)</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060115.html?DbPAR=CALC">Funções de suplemento (add-in), lista das funções de análise - Parte 1</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060116.html?DbPAR=CALC">Funções de suplemento (add-in), lista das funções de análise - Parte 2</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/01/04060199.html?DbPAR=CALC">Operadores no LibreOffice Calc</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Funções definidas pelo usuário</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Carregar, salvar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/webquery.html?DbPAR=CALC">Inserir dados externos em tabelas (Consulta na Web)</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/html_doc.html?DbPAR=CALC">Salvar e abrir planilhas em HTML</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importar e exportar arquivos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redaction.html?DbPAR=CALC">Censura</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatação</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotação de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/text_wrap.html?DbPAR=CALC">Escrever texto em várias linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatar números como texto</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/super_subscript.html?DbPAR=CALC">Texto sobrescrito / subscrito</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/row_height.html?DbPAR=CALC">Alterar a altura da linha ou a largura da coluna</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Aplicar formatação condicional</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Realçar números negativos</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Atribuir formatos por fórmula</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Inserir números com zeros à esquerda</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/format_table.html?DbPAR=CALC">Formatar documentos de planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/format_value.html?DbPAR=CALC">Formatar números com decimais</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/value_with_name.html?DbPAR=CALC">Nomear células</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotação de tabelas (transposição)</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/rename_table.html?DbPAR=CALC">Renomear planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/year2000.html?DbPAR=CALC">Anos 19xx/20xx</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Utilizar números arredondados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/currency_format.html?DbPAR=CALC">Células em formato monetário</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/autoformat.html?DbPAR=CALC">Utilização de Autoformatação para tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/note_insert.html?DbPAR=CALC">Inserir e editar anotações</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/design.html?DbPAR=CALC">Selecionar temas para planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Inserir frações</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtros e ordenação</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/filters.html?DbPAR=CALC">Aplicar filtros</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filtro: Aplicar filtros avançados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/autofilter.html?DbPAR=CALC">Aplicar autofiltro</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/sorted_list.html?DbPAR=CALC">Aplicar listas de ordenação</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Impressão</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/print_title_row.html?DbPAR=CALC">Imprimir linhas ou colunas em todas as páginas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/print_landscape.html?DbPAR=CALC">Imprimir planilhas em formato de paisagem</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/print_details.html?DbPAR=CALC">Imprimir detalhes da planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/print_exact.html?DbPAR=CALC">Definir número de páginas para a impressão</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Intervalos de dados</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/database_define.html?DbPAR=CALC">Definir intervalos de banco de dados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrar intervalos de células</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/database_sort.html?DbPAR=CALC">Ordenar dados</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Tabela dinâmica</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot.html?DbPAR=CALC">Tabela dinâmica</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Criar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Excluir tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Editar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrar tabelas dinâmicas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Selecionar intervalos de saída da tabela dinâmica</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Atualizar tabelas dinâmicas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Gráficos Dinâmicos</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart.html?DbPAR=CALC">Gráfico dinâmico</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Criar gráficos dinâmicos</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editar gráficos dinâmicos</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrar gráfico dinâmicos</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Atualizar gráfico dinâmico</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Excluir gráficos dinâmicos</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Cenários</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/scenario.html?DbPAR=CALC">Utilizar cenários</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referências</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Endereços e referências, absolutas e relativas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellreferences.html?DbPAR=CALC">Referenciar uma célula de outro documento</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Referências para outras planilhas e referenciar URLs</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Referenciar células ao arrastar e soltar</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/address_auto.html?DbPAR=CALC">Reconhecer nomes como endereço</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Ver, selecionar e copiar</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/table_view.html?DbPAR=CALC">Alterar exibição de tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/formula_value.html?DbPAR=CALC">Exibir fórmulas ou valores</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/line_fix.html?DbPAR=CALC">Congelar linhas ou colunas como cabeçalhos</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navegar através de guias de planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copiar para várias planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copiar somente das células visíveis</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/mark_cells.html?DbPAR=CALC">Selecionar várias células</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Fórmulas e cálculos</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/formulas.html?DbPAR=CALC">Calcular com fórmulas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copiar fórmulas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/formula_enter.html?DbPAR=CALC">Inserir fórmulas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/formula_value.html?DbPAR=CALC">Exibir fórmulas ou valores</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/calculate.html?DbPAR=CALC">Calcular em documentos de planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/calc_date.html?DbPAR=CALC">Cálculo com datas e horas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/calc_series.html?DbPAR=CALC">Cálculo automático de séries</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Calcular diferenças de tempo</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/matrixformula.html?DbPAR=CALC">Inserir fórmulas de matriz</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Proteção</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cell_protect.html?DbPAR=CALC">Proteger células contra alterações</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Desproteger células</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Diversos</label><ul>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/auto_off.html?DbPAR=CALC">Desativar alterações automáticas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidar dados</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/goalseek.html?DbPAR=CALC">Atingir meta</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/multioperation.html?DbPAR=CALC">Aplicar operações múltiplas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/multitables.html?DbPAR=CALC">Aplicar várias planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/scalc/guide/validity.html?DbPAR=CALC">Validação do conteúdo de células</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Gráficos e diagramas</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informações gerais</label><ul>\
    <li><a target="_top" href="pt-BR/text/schart/main0000.html?DbPAR=CHART">Gráficos no LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/schart/main0503.html?DbPAR=CHART">Recursos do LibreOffice Chart</a></li>\
    <li><a target="_top" href="pt-BR/text/schart/04/01020000.html?DbPAR=CHART">Atalhos para gráficos</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Instalação  do LibreOffice</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Alterar a associação de tipos de documentos do Microsoft Office</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Modo de segurança</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Tópicos de ajuda</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informações gerais</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/main0400.html?DbPAR=SHARED">Teclas de atalho</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/00/00000005.html?DbPAR=SHARED">Glossário geral</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/00/00000002.html?DbPAR=SHARED">Glossário de termos da Internet</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/accessibility.html?DbPAR=SHARED">Acessibilidade no LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/keyboard.html?DbPAR=SHARED">Atalhos (Acessibilidade do LibreOffice)</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/04/01010000.html?DbPAR=SHARED">Teclas de atalho gerais do LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/version_number.html?DbPAR=SHARED">Versões e números de compilação</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice e Microsoft Office</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/ms_user.html?DbPAR=SHARED">Utilizar o Microsoft Office e o LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparação de termos do Microsoft Office e do LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Sobre a conversão de documentos do Microsoft Office</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Alterar a associação de tipos de documentos do Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Opções do LibreOffice</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01000000.html?DbPAR=SHARED">Opções</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010100.html?DbPAR=SHARED">Dados de usuário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010200.html?DbPAR=SHARED">Geral</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010300.html?DbPAR=SHARED">Caminhos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010400.html?DbPAR=SHARED">Recursos de verificação ortográfica</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010600.html?DbPAR=SHARED">Geral</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010700.html?DbPAR=SHARED">Fontes</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010800.html?DbPAR=SHARED">Exibir</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01010900.html?DbPAR=SHARED">Imprimir</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01012000.html?DbPAR=SHARED">Cores da aplicação</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01013000.html?DbPAR=SHARED">Acessibilidade</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/java.html?DbPAR=SHARED">Avançado</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Configuração para especialistas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">IDE do Basic</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01020000.html?DbPAR=SHARED">Opções para carregar/salvar</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01030000.html?DbPAR=SHARED">Opções da internet</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01040000.html?DbPAR=SHARED">Opções de documento de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01050000.html?DbPAR=SHARED">Opções de documentos HTML</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01060000.html?DbPAR=SHARED">Opções de planilha</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01070000.html?DbPAR=SHARED">Opções de apresentação</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01080000.html?DbPAR=SHARED">Opções de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01090000.html?DbPAR=SHARED">Fórmula</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01110000.html?DbPAR=SHARED">Opções de gráfico</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01130100.html?DbPAR=SHARED">Propriedades do VBA</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01140000.html?DbPAR=SHARED">Idiomas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01150000.html?DbPAR=SHARED">Opções para configuração de idioma</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/optionen/01160000.html?DbPAR=SHARED">Opções de fontes de dados</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Assistentes</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01000000.html?DbPAR=SHARED">Assistente</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Assistente de cartas</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01010000.html?DbPAR=SHARED">Assistente de cartas</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Assistente de faxes</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01020000.html?DbPAR=SHARED">Assistente de Fax</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Assistente de agendas</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01040000.html?DbPAR=SHARED">Assistente de Agendas</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Assistente de exportação HTML</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01110000.html?DbPAR=SHARED">Exportação de HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Assistente de conversão de documentos</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01130000.html?DbPAR=SHARED">Conversor de documentos</a></li>\
			</ul></li>\
    <li><a target="_top" href="pt-BR/text/shared/autopi/01150000.html?DbPAR=SHARED">Assistente de Conversão de Euros</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configurar o LibreOffice</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configurar o LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/packagemanager.html?DbPAR=SHARED">Gerenciador de extensão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/flat_icons.html?DbPAR=SHARED">Alterar a exibição dos ícones</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Adicionar botões nas barras de ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/workfolder.html?DbPAR=SHARED">Alterar seu diretório de trabalho</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/standard_template.html?DbPAR=SHARED">Alterar os modelos padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Registrar um catálogo de endereços</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/formfields.html?DbPAR=SHARED">Inserir e editar botões</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Trabalhar com a interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navegação para alcançar objetos rapidamente</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/navigator.html?DbPAR=SHARED">Navegador para visão geral do documento</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/autohide.html?DbPAR=SHARED">Exibir, encaixar e ocultar janelas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/textmode_change.html?DbPAR=SHARED">Alternar entre o modo de inserir e o de sobrescrever</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Utilizar barras de ferramentas</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Assinaturas digitais</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Sobre assinaturas digitais</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Assinar com assinaturas digitais</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Assinatura digital na exportação PDF</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Assinar PDF existente</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/01/addsignatureline.html?DbPAR=SHARED">Adiciona a Linha de assinatura nos Documentos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/01/signsignatureline.html?DbPAR=SHARED">Assinando a Linha de assinatura</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Imprimir, faxes e envios</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/labels_database.html?DbPAR=SHARED">Imprimir etiquetas de endereço</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Imprimir em preto e branco</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/email.html?DbPAR=SHARED">Enviar documentos por e-mail</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/fax.html?DbPAR=SHARED">Enviar fax e configurar o LibreOffice para enviar fax</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Arrastar & soltar</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop.html?DbPAR=SHARED">Arrastar e soltar dentro de um documento do LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Mover e copiar texto em documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de planilhas para documentos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar figuras entre documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiar figuras da Galeria</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Arrastar e soltar com a exibição de fonte de dados</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copiar e colar</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copiar objetos de desenho para outros documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copiar figuras entre documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copiar figuras da Galeria</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copiar áreas de planilhas para documentos de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Gráficos e diagramas</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/chart_insert.html?DbPAR=SHARED">Inserir gráficos</a></li>\
    <li><a target="_top" href="pt-BR/text/schart/main0000.html?DbPAR=SHARED">Gráficos no LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Carregar, salvar, importar, exportar, PDF</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/doc_open.html?DbPAR=SHARED">Abrir documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/import_ms.html?DbPAR=SHARED">Abrir documentos salvos em outros formatos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/doc_save.html?DbPAR=SHARED">Salvar documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Salvar documentos automaticamente</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/export_ms.html?DbPAR=SHARED">Salvar documentos em outros formatos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportar como PDF</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Importar e exportar dados em formato de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Links e referências</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Inserir hyperlinks</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Vínculos relativos e absolutos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Editar hiperlinks</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Registro da versão do documento</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparar versões de um documento</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Mesclar versões</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Registrar alterações</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining.html?DbPAR=SHARED">Registrar e exibir alterações</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Aceitar ou rejeitar alterações</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Gerenciar versões</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiquetas e cartões de visita</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/labels.html?DbPAR=SHARED">Criar e imprimir etiquetas e cartões de visita</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Inserir dados externos</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/copytable2application.html?DbPAR=SHARED">Inserir dados a partir de planilhas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/copytext2application.html?DbPAR=SHARED">Inserir dados a partir de documentos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Inserir, editar, salvar bitmaps</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Adicionar figuras à Galeria</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Funções automáticas</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Desativar o reconhecimento automático de URLs</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Localizar e substituir</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_search2.html?DbPAR=SHARED">Pesquisar com um filtro de formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_search.html?DbPAR=SHARED">Pesquisar tabelas e documentos de formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/02100001.html?DbPAR=SHARED">Lista de expressões regulares</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guias</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/guide/linestyles.html?DbPAR=SHARED">Aplicar estilos de linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/text_color.html?DbPAR=SHARED">Alterar a cor do texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/change_title.html?DbPAR=SHARED">Alterar o título de um documento</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/round_corner.html?DbPAR=SHARED">Criar cantos arredondados</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/background.html?DbPAR=SHARED">Definir cores ou figuras de plano de fundo</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/lineend_define.html?DbPAR=SHARED">Definir extremidades de linha</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Definir estilos de linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Editar objetos gráficos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/line_intext.html?DbPAR=SHARED">Desenhar linhas em texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/aaa_start.html?DbPAR=SHARED">Primeiros passos</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Inserir objetos a partir da Galeria</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserir espaços inseparáveis, hifens e hifens opcionais</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Inserir caracteres especiais</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/tabs.html?DbPAR=SHARED">Inserir e editar paradas de tabulação</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/protection.html?DbPAR=SHARED">Proteger o conteúdo no LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Proteger registros</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Selecionar a área máxima imprimível em uma página</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/measurement_units.html?DbPAR=SHARED">Selecionar unidades de medida</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/language_select.html?DbPAR=SHARED">Selecionar o idioma do documento</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Design de tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Desativar numeração e marcadores de parágrafos individuais</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Funcionalidade de banco de dados (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informação geral</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/explorer/database/main.html?DbPAR=SHARED">Banco de dados do LibreOffice</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/database_main.html?DbPAR=SHARED">Visão geral de banco de dados</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_new.html?DbPAR=SHARED">Criar um novo banco de dados</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_tables.html?DbPAR=SHARED">Trabalhar com tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_queries.html?DbPAR=SHARED">Trabalhar com consultas</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_forms.html?DbPAR=SHARED">Trabalhar com formulários</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_reports.html?DbPAR=SHARED">Criar relatórios</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_register.html?DbPAR=SHARED">Registrar e excluir um banco de dados</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_im_export.html?DbPAR=SHARED">Importar e exportar dados no Base</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/data_enter_sql.html?DbPAR=SHARED">Executar comandos SQL</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Apresentações (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/main0000.html?DbPAR=IMPRESS">Bem-vindo à Ajuda do LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0503.html?DbPAR=IMPRESS">Recursos do LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Utilizar teclas de atalho no LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/04/01020000.html?DbPAR=IMPRESS">Teclas de atalho no LibreOffice Impress</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/04/presenter.html?DbPAR=IMPRESS">Teclas de atalho do console do apresentador</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/main.html?DbPAR=IMPRESS">Instruções para utilizar o LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menus</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/main0100.html?DbPAR=IMPRESS">Menus</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0101.html?DbPAR=IMPRESS">Arquivo</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main_edit.html?DbPAR=IMPRESS">Editar</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0103.html?DbPAR=IMPRESS">Exibir</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0104.html?DbPAR=IMPRESS">Inserir</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main_format.html?DbPAR=IMPRESS">Formatar</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0114.html?DbPAR=IMPRESS">Apresentação de slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main_tools.html?DbPAR=IMPRESS">Ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0107.html?DbPAR=IMPRESS">Janela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0108.html?DbPAR=IMPRESS">Ajuda</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/main0200.html?DbPAR=IMPRESS">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0202.html?DbPAR=IMPRESS">Barra Linha e preenchimento</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0203.html?DbPAR=IMPRESS">Barra Formatação de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0204.html?DbPAR=IMPRESS">Barra de objetos na exibição de slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0206.html?DbPAR=IMPRESS">Barra de status</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0209.html?DbPAR=IMPRESS">Réguas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0210.html?DbPAR=IMPRESS">Barra Desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0211.html?DbPAR=IMPRESS">Barra Estrutura de tópicos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0212.html?DbPAR=IMPRESS">Barra Organizador de slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0213.html?DbPAR=IMPRESS">Barra Opções</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0214.html?DbPAR=IMPRESS">Barra de figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0201.html?DbPAR=IMPRESS">Barra Padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0213.html?DbPAR=IMPRESS">Barra de ferramentas Formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0226.html?DbPAR=IMPRESS">Barra de ferramentas Design de formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0227.html?DbPAR=IMPRESS">Barra Editar pontos</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Carregar, salvar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Salvar uma apresentação em formato HTML</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Importar páginas HTML para apresentações</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Carregar listas de cores, gradientes e hachuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animações no formato GIF</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Incluir planilhas em slides</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Copiar slides de outras apresentações</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redaction.html?DbPAR=IMPRESS">Censura</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatação</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Carregar listas de cores, gradientes e hachuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Carregar estilos de linhas e setas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Criar gradiente de preenchimento</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Substituir cores</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Dispor, alinhar e distribuir objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/background.html?DbPAR=IMPRESS">Alterar o preenchimento do plano de fundo do slide</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/footer.html?DbPAR=IMPRESS">Adicionar um cabeçalho ou um rodapé em todos os slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Alterar e adicionar uma página mestre</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover objetos</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Impressão</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/printing.html?DbPAR=IMPRESS">Imprimir apresentações</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Imprimir um slide para caber no tamanho do papel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Efeitos</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportar animações no formato GIF</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animar objetos nos slides da apresentação</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animar transições de slides</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Transição de dois objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Criar imagens GIF animadas</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objetos, figuras e bitmaps</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Combinar objetos e construir formas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Agrupar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Desenhar setores e segmentos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplicar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Girar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Compor objetos 3D</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Conectar linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto em objetos de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Converter imagens de bitmap em figura vetorial</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Converter objetos 2D em curvas, polígonos e objetos 3D</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Carregar estilos de linhas e setas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Desenhar curvas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Editar curvas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Inserir figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Incluir planilhas em slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Mover objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Selecionar objetos ocultos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Criar um fluxograma</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Texto em apresentações</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Adicionar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Converter caracteres de texto em objetos de desenho</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Visualizar</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Alterar a ordem dos slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoom com o teclado numérico</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Apresentação de slides</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/show.html?DbPAR=IMPRESS">Mostrar a apresentação de slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Usando a console do apresentador</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Guia do controle remoto do Impress</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/individual.html?DbPAR=IMPRESS">Criar uma apresentação de slides personalizada</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Ensaio cronometrado de trocas de slides</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Fórmulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/smath/main0000.html?DbPAR=MATH">Bem-vindo à Ajuda do LibreOffice Math</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/main0503.html?DbPAR=MATH">Recursos do LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Elementos de fórmula do LibreOffice</label><ul>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090100.html?DbPAR=MATH">Operadores unários/binários</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090200.html?DbPAR=MATH">Relações</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090800.html?DbPAR=MATH">Operações de conjuntos</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090400.html?DbPAR=MATH">Funções</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090300.html?DbPAR=MATH">Operadores</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090600.html?DbPAR=MATH">Atributos</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090500.html?DbPAR=MATH">Parênteses</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03090700.html?DbPAR=MATH">Formatar</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/01/03091600.html?DbPAR=MATH">Outros símbolos</a></li>\
            </ul></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/main.html?DbPAR=MATH">Instruções para a utilização do LibreOffice Math</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/keyboard.html?DbPAR=MATH">Atalhos (acessibilidade do LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Referência de comandos e de menu</label><ul>\
    <li><a target="_top" href="pt-BR/text/smath/main0100.html?DbPAR=MATH">Menus</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/main0200.html?DbPAR=MATH">Barras de ferramentas</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Trabalhar com fórmulas</label><ul>\
    <li><a target="_top" href="pt-BR/text/smath/guide/align.html?DbPAR=MATH">Alinhamento manual de partes de fórmulas</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/attributes.html?DbPAR=MATH">Alterar os atributos padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/brackets.html?DbPAR=MATH">Mesclar partes de fórmulas entre parênteses</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/comment.html?DbPAR=MATH">Inserir comentários</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/newline.html?DbPAR=MATH">Inserir quebras de linha</a></li>\
    <li><a target="_top" href="pt-BR/text/smath/guide/parentheses.html?DbPAR=MATH">Inserir parênteses</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="02"><label for="02">Documentos de texto (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/main0000.html?DbPAR=WRITER">Bem-vindo à Ajuda do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0503.html?DbPAR=WRITER">Recursos do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/main.html?DbPAR=WRITER">Instruções para a utilização do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Encaixar e redimensionar janelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/04/01020000.html?DbPAR=WRITER">Teclas de atalho do LibreOffice Writer</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/words_count.html?DbPAR=WRITER">Contagem de palavras</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/keyboard.html?DbPAR=WRITER">Utilizar teclas de atalho (Acessibilidade do LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menus</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/main0100.html?DbPAR=WRITER">Menus</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0101.html?DbPAR=WRITER">Arquivo</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0102.html?DbPAR=WRITER">Editar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0103.html?DbPAR=WRITER">Exibir</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0104.html?DbPAR=WRITER">Inserir</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0105.html?DbPAR=WRITER">Formatar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0115.html?DbPAR=WRITER">Estilos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0110.html?DbPAR=WRITER">Tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0120.html?DbPAR=WRITER">Menu Formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0106.html?DbPAR=WRITER">Ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0107.html?DbPAR=WRITER">Janela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0108.html?DbPAR=WRITER">Ajuda</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/main0200.html?DbPAR=WRITER">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0202.html?DbPAR=WRITER">Barra de formatação</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0203.html?DbPAR=WRITER">Barra de figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0204.html?DbPAR=WRITER">Barra de tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0205.html?DbPAR=WRITER">Barra Propriedades do objeto de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0206.html?DbPAR=WRITER">Barra Marcadores e numeração</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0208.html?DbPAR=WRITER">Barra de status</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0210.html?DbPAR=WRITER">Visualizar Impressão</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0213.html?DbPAR=WRITER">Réguas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0214.html?DbPAR=WRITER">Barra de fórmulas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0215.html?DbPAR=WRITER">Barra de quadro</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0216.html?DbPAR=WRITER">Barra de objetos OLE</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/main0220.html?DbPAR=WRITER">Barra de objetos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0201.html?DbPAR=WRITER">Barra Padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0212.html?DbPAR=WRITER">Barra Dados da tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0213.html?DbPAR=WRITER">Barra de ferramentas Formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0214.html?DbPAR=WRITER">Barra Design de consulta</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0226.html?DbPAR=WRITER">Barra de ferramentas Design de formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barra de ferramentas LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Criar documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navegar e selecionar com o teclado</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Utilizar o cursor direto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Figuras em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Inserir figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Inserir uma figura de um arquivo</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Inserir figuras da Galeria utilizando o método arrastar e soltar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Inserir uma imagem digitalizada</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Inserir um gráfico do Calc em um documento de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Inserir figuras do LibreOffice Draw ou Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabelas em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ativar e desativar o reconhecimento de números em tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modificar linhas e colunas usando o teclado</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/table_delete.html?DbPAR=WRITER">Excluir tabelas ou o conteúdo de uma tabela</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/table_insert.html?DbPAR=WRITER">Inserir tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Repetir um título de tabela em uma nova página</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Redimensionar linhas e colunas em uma tabela de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objetos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Posicionar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/wrap.html?DbPAR=WRITER">Disposição do texto ao redor de objetos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Seções e quadros em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/sections.html?DbPAR=WRITER">Utilizar seções</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserir, editar e vincular quadros</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/section_edit.html?DbPAR=WRITER">Editar seções</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/section_insert.html?DbPAR=WRITER">Inserir seções</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Sumários e índices</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeração de capítulos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Índices personalizados</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Criar um sumário</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_index.html?DbPAR=WRITER">Criar índices alfabéticos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Índices que abrangem vários documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Criar uma bibliografia</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Editar ou excluir entradas de índices e de sumários</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Atualizar, editar e excluir índices e sumários</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Definir entradas de índice ou de sumário</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatar um índice ou de um índice geral</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Campos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/fields.html?DbPAR=WRITER">Sobre campos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir um campo de data fixo ou variável</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/field_convert.html?DbPAR=WRITER">Converter um campo em texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Navegação em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Mover e copiar texto em documentos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Reorganizar um documento utilizando o Navegador</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hyperlinks pelo Navegador</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/navigator.html?DbPAR=WRITER">Navegador de documentos de texto</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Cálculos em documentos de texto</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Calcular com várias tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate.html?DbPAR=WRITER">Calcular em documentos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcular e colar o resultado de uma fórmula em um documento de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calcular totais de células em tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calcular fórmulas complexas em documentos de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Exibir o resultado de um cálculo com tabelas em uma tabela diferente</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formatar documentos de texto</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Modelos e estilos</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Modelos e estilos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternar estilos de página em páginas ímpares e pares</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/change_header.html?DbPAR=WRITER">Criar um estilo de página com base na página atual</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/load_styles.html?DbPAR=WRITER">Utilizar estilos de outro documento ou modelo</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Criar novos estilos a partir de seleções</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Atualizar estilos a partir da seleção</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/template_create.html?DbPAR=WRITER">Criar um modelo de documento</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/template_default.html?DbPAR=WRITER">Alterar o modelo padrão</a></li>\
			</ul></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Alterar a orientação de página (paisagem ou retrato)</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_capital.html?DbPAR=WRITER">Alterar a caixa do texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ocultar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeçalhos e rodapés diferentes</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir nome e número do capítulo em um cabeçalho ou rodapé</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Formatar texto ao digitar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/reset_format.html?DbPAR=WRITER">Redefinir os atributos de fonte</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Aplicar estilos em modo de preenchimento de formato</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/wrap.html?DbPAR=WRITER">Disposição do texto ao redor de objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Utilizar um quadro para centralizar texto em uma página</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Enfatizar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Girar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/page_break.html?DbPAR=WRITER">Inserir e excluir quebras de página</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Criar e utilizar estilos de página</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/subscript.html?DbPAR=WRITER">Converter texto em subscrito ou sobrescrito</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Elementos de texto especiais</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/captions.html?DbPAR=WRITER">Utilizar legendas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Texto condicional</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Texto condicional para contagens de páginas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/fields_date.html?DbPAR=WRITER">Inserir um campo de data fixo ou variável</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Adicionar campos de entrada</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Inserir números em páginas de continuação</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Inserir números de página em rodapés</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Ocultar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definir cabeçalhos e rodapés diferentes</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Inserir nome e número do capítulo em um cabeçalho ou rodapé</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Consultar dados do usuário em campos ou condições</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Inserir e editar notas de rodapé ou de notas de fim</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Espaçamento entre notas de rodapé</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_footer.html?DbPAR=WRITER">Sobre cabeçalhos e rodapés</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatar cabeçalhos ou rodapés</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animação de texto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Criar uma carta-modelo</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Funções automáticas</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Adicionar exceções à lista de autocorreção</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/autotext.html?DbPAR=WRITER">Utilizar o autotexto</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Criar listas numeradas ou com marcadores ao digitar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/auto_off.html?DbPAR=WRITER">Desativar a autocorreção</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificação ortográfica automática</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ativar e desativar o reconhecimento de números em tabelas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Hifenização</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numeração e listas</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Adicionar números de capítulos em legendas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Criar listas numeradas ou com marcadores ao digitar</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numeração de capítulos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Alterar o nível dos capítulos das listas numeradas e com marcadores</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinar listas numeradas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Adicionar números de linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modificar a numeração em uma lista numerada</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definir intervalos de números</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Adicionar numeração</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numeração e estilos de numeração</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Adicionar marcadores</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Corretor ortográfico, sinônimos e idiomas</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Verificação ortográfica automática</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Remover palavras de um dicionário definido pelo usuário</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Dicionário de sinônimos</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Verificar ortografia e gramática</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Dicas para resolução de problemas</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Inserir texto antes de uma tabela no topo da página</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Posicionar o cursor em marcadores específicos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Carregar, salvar, importar, exportar e censurar</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/send2html.html?DbPAR=WRITER">Salvar documentos de texto em formato HTML</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Inserir um documento de texto inteiro</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/guide/redaction.html?DbPAR=WRITER">Censura</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Documentos mestre</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Documentos mestres e subdocumentos</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Links e referências</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/references.html?DbPAR=WRITER">Inserir referências</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Inserir hyperlinks pelo Navegador</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Impressão</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Selecionar bandejas de papel da impressora</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/print_preview.html?DbPAR=WRITER">Visualização de uma página antes da impressão</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/print_small.html?DbPAR=WRITER">Imprimir várias páginas na mesma folha</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Criar e utilizar estilos de página</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Localizar e substituir</label><ul>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Usar expressões regulares em buscas textuais</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/01/02100001.html?DbPAR=WRITER">Lista de expressões regulares</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documentos HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="pt-BR/text/shared/07/09000000.html?DbPAR=WRITER">Páginas da Web</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/02/01170700.html?DbPAR=WRITER">Formulários e filtros HTML</a></li>\
    <li><a target="_top" href="pt-BR/text/swriter/guide/send2html.html?DbPAR=WRITER">Salvar documentos de texto em formato HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Desenhos (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informações gerais e utilização da interface</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0000.html?DbPAR=DRAW">Bem-vindo à Ajuda do LibreOffice Draw</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0503.html?DbPAR=DRAW">Recursos do LibreOffice Draw</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Teclas de atalho para objetos de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/04/01020000.html?DbPAR=DRAW">Teclas de atalho para desenhos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/main.html?DbPAR=DRAW">Instruções para utilizar o LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Referência de comandos e de menu</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0100.html?DbPAR=DRAW">Menus</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0101.html?DbPAR=DRAW">Arquivo</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_edit.html?DbPAR=DRAW">Editar</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0103.html?DbPAR=DRAW">Exibir</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_insert.html?DbPAR=DRAW">Inserir</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_format.html?DbPAR=DRAW">Formatar</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_page.html?DbPAR=DRAW">Página</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_shape.html?DbPAR=DRAW">Forma</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main_tools.html?DbPAR=DRAW">Ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/main0107.html?DbPAR=DRAW">Janela</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0108.html?DbPAR=DRAW">Ajuda</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barras de ferramentas</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0200.html?DbPAR=DRAW">Barras de ferramentas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0210.html?DbPAR=DRAW">Barra Desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/main0213.html?DbPAR=DRAW">Barra Opções</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0201.html?DbPAR=DRAW">Barra Padrão</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0213.html?DbPAR=DRAW">Barra de ferramentas Formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0226.html?DbPAR=DRAW">Barra de ferramentas Design de formulário</a></li>\
    <li><a target="_top" href="pt-BR/text/shared/main0227.html?DbPAR=DRAW">Barra Editar pontos</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Carregar, salvar, importar e exportar</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/palette_files.html?DbPAR=DRAW">Carregar listas de cores, gradientes e hachuras</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir figuras</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatação</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/palette_files.html?DbPAR=DRAW">Carregar listas de cores, gradientes e hachuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Carregar estilos de linhas e setas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/color_define.html?DbPAR=DRAW">Definir cores personalizadas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/gradient.html?DbPAR=DRAW">Criar gradiente de preenchimento</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Substituir cores</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Dispor, alinhar e distribuir objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/background.html?DbPAR=DRAW">Alterar o preenchimento do plano de fundo do slide</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/masterpage.html?DbPAR=DRAW">Alterar e adicionar uma página mestre</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover objetos</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Imprimir</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/printing.html?DbPAR=DRAW">Imprimir apresentações</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Imprimir um slide para caber no tamanho do papel</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Efeitos</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Transição de dois objetos</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objetos, figuras e bitmaps</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Combinar objetos e construir formas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Desenhar setores e segmentos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplicar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Girar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Compor objetos 3D</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Conectar linhas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto em objetos de desenho</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/vectorize.html?DbPAR=DRAW">Converter imagens de bitmap em figura vetorial</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/3d_create.html?DbPAR=DRAW">Converter objetos 2D em curvas, polígonos e objetos 3D</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Carregar estilos de linhas e setas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_draw.html?DbPAR=DRAW">Desenhar curvas</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/line_edit.html?DbPAR=DRAW">Editar curvas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Inserir figuras</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/table_insert.html?DbPAR=DRAW">Incluir planilhas em slides</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/move_object.html?DbPAR=DRAW">Mover objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/select_object.html?DbPAR=DRAW">Selecionar objetos ocultos</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/orgchart.html?DbPAR=DRAW">Criar um fluxograma</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Grupos e camadas</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/groups.html?DbPAR=DRAW">Agrupar objetos</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/layers.html?DbPAR=DRAW">Sobre camadas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserir camadas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Trabalhar com camadas</a></li>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Mover objetos para uma camada diferente</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Texto em desenhos</label><ul>\
    <li><a target="_top" href="pt-BR/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Adicionar texto</a></li>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/text2curve.html?DbPAR=DRAW">Converter caracteres de texto em objetos de desenho</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Visualizar</label><ul>\
    <li><a target="_top" href="pt-BR/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoom com o teclado numérico</a></li>\
         </ul></li>\
     </ul></li></ul>\
';
