document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="07"><label for="07">Makros und Skripte</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/sbasic/shared/main0601.html?DbPAR=BASIC">Hilfe zu LibreOffice Basic</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmieren mit LibreOffice Basic</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic-Glossar</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01010210.html?DbPAR=BASIC">Grundlagen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntax</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic-IDE</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01030100.html?DbPAR=BASIC">Überblick IDE</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01030200.html?DbPAR=BASIC">Der Basic-Editor</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01050100.html?DbPAR=BASIC">Beobachterfenster</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/main0211.html?DbPAR=BASIC">Symbolleiste Makro</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/05060700.html?DbPAR=BASIC">Makro</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Unterstützung für VBA-Makros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Befehlsreferenz</label><ul>\
    <li><a target="_top" href="de/text/sbasic/shared/01020300.html?DbPAR=BASIC">Arbeiten mit Prozeduren und Funktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliotheken, Module und Dialoge</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Funktionen, Anweisungen und Operatoren</label><ul>\
    <li><a target="_top" href="de/text/sbasic/shared/03010000.html?DbPAR=BASIC">Funktionen für Bildschirmein-/ausgabe</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020000.html?DbPAR=BASIC">Dateiein-/ausgabefunktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030000.html?DbPAR=BASIC">Datums- und Zeitfunktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fehlerbehandlungsfunktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060000.html?DbPAR=BASIC">Logische Operatoren</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070000.html?DbPAR=BASIC">Mathematische Operatoren</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerische Funktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090000.html?DbPAR=BASIC">Steuern von Programmabläufen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variablen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic-Konstanten</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03110000.html?DbPAR=BASIC">Vergleichsoperatoren</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120000.html?DbPAR=BASIC">Zeichenketten</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO-Objekte</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exklusive VBA-Funktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130000.html?DbPAR=BASIC">Sonstige Befehle</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetische Liste der Funktionen, Anweisungen und Operatoren</label><ul>\
    <li><a target="_top" href="de/text/sbasic/shared/03080601.html?DbPAR=BASIC">Funktion Abs</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060100.html?DbPAR=BASIC">Operator AND</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104200.html?DbPAR=BASIC">Funktion Array</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120101.html?DbPAR=BASIC">Funktion Asc</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120111.html?DbPAR=BASIC">Funktion AscW</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080101.html?DbPAR=BASIC">Funktion Atn</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130100.html?DbPAR=BASIC">Anweisung Beep</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010301.html?DbPAR=BASIC">Funktion Blue</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100100.html?DbPAR=BASIC">Funktion CBool</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120105.html?DbPAR=BASIC">Funktion CByte</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100050.html?DbPAR=BASIC">Funktion CCur</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030116.html?DbPAR=BASIC">Funktion CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030115.html?DbPAR=BASIC">Funktion CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030114.html?DbPAR=BASIC">Funktion CDateFromUnoTime</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030113.html?DbPAR=BASIC">Funktion CDateToUnoTime</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030112.html?DbPAR=BASIC">Funktion CDateFromUnoDate</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030111.html?DbPAR=BASIC">Funktion CDateToUnoDate</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030108.html?DbPAR=BASIC">Funktion CDateFromIso</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030107.html?DbPAR=BASIC">Funktion CDateToIso</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100300.html?DbPAR=BASIC">Funktion CDate</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100400.html?DbPAR=BASIC">Funktion CDbl</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100060.html?DbPAR=BASIC">Funktion CDec</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100500.html?DbPAR=BASIC">Funktion CInt</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100600.html?DbPAR=BASIC">Funktion CLng</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100900.html?DbPAR=BASIC">Funktion CSng</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101000.html?DbPAR=BASIC">Funktion CStr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090401.html?DbPAR=BASIC">Anweisung Call</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020401.html?DbPAR=BASIC">Anweisung ChDir</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020402.html?DbPAR=BASIC">Anweisung ChDrive</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090402.html?DbPAR=BASIC">Funktion Choose</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120102.html?DbPAR=BASIC">Funktion Chr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120112.html?DbPAR=BASIC">Funktion ChrW [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020101.html?DbPAR=BASIC">Anweisung Close</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03110100.html?DbPAR=BASIC">Vergleichsoperatoren</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100700.html?DbPAR=BASIC">Anweisung Const</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120313.html?DbPAR=BASIC">Funktion ConvertFromURL</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120312.html?DbPAR=BASIC">Funktion ConvertToURL</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080102.html?DbPAR=BASIC">Funktion Cos</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132400.html?DbPAR=BASIC">Funktion CreateObject</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131800.html?DbPAR=BASIC">Funktion CreateUnoDialog</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132000.html?DbPAR=BASIC">Funktion CreateUnoListener</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131600.html?DbPAR=BASIC">Funktion CreateUnoService</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131500.html?DbPAR=BASIC">Funktion CreateUnoStruct</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132300.html?DbPAR=BASIC">Funktion CreateUnoValue</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020403.html?DbPAR=BASIC">Funktion CurDir</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100070.html?DbPAR=BASIC">Funktion CVar</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03100080.html?DbPAR=BASIC">Funktion CVErr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030110.html?DbPAR=BASIC">Funktion DateAdd</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030120.html?DbPAR=BASIC">Funktion DateDiff</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030130.html?DbPAR=BASIC">Funktion DatePart</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030101.html?DbPAR=BASIC">Funktion DateSerial</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030102.html?DbPAR=BASIC">Funktion DateValue</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030301.html?DbPAR=BASIC">Anweisung Date</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030103.html?DbPAR=BASIC">Funktion Day</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140000.html?DbPAR=BASIC">Funktion DDB [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090403.html?DbPAR=BASIC">Anweisung Declare</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101100.html?DbPAR=BASIC">Anweisung DefBool</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101300.html?DbPAR=BASIC">Anweisung DefDate</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101400.html?DbPAR=BASIC">Anweisung DefDbl</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101500.html?DbPAR=BASIC">Anweisung DefInt</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101600.html?DbPAR=BASIC">Anweisung DefLng</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03101700.html?DbPAR=BASIC">Anweisung DefObj</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102000.html?DbPAR=BASIC">Anweisung DefVar</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104300.html?DbPAR=BASIC">Funktion DimArray</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102100.html?DbPAR=BASIC">Anweisung Dim</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020404.html?DbPAR=BASIC">Funktion Dir</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090201.html?DbPAR=BASIC">Anweisung Do...Loop</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03110100.html?DbPAR=BASIC">Vergleichsoperatoren</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090404.html?DbPAR=BASIC">Anweisung End</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/enum.html?DbPAR=BASIC">Anweisung Enum</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130800.html?DbPAR=BASIC">Funktion Environ</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020301.html?DbPAR=BASIC">Funktion Eof</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104600.html?DbPAR=BASIC">Funktion EqualUnoObjects</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060200.html?DbPAR=BASIC">Operator Eqv</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050100.html?DbPAR=BASIC">Funktion Erl</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050200.html?DbPAR=BASIC">Funktion Err</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050300.html?DbPAR=BASIC">Funktion Error</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fehlerbehandlungsfunktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090412.html?DbPAR=BASIC">Anweisung Exit</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080201.html?DbPAR=BASIC">Funktion Exp</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020405.html?DbPAR=BASIC">Funktion FileAttr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020406.html?DbPAR=BASIC">Anweisung FileCopy</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020407.html?DbPAR=BASIC">Funktion FileDateTime</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020415.html?DbPAR=BASIC">Funktion FileExists</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020408.html?DbPAR=BASIC">Funktion FileLen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103800.html?DbPAR=BASIC">Funktion FindObject</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103900.html?DbPAR=BASIC">Funktion FindPropertyObject</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080501.html?DbPAR=BASIC">Funktion Fix</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090202.html?DbPAR=BASIC">Anweisung For...Next</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120301.html?DbPAR=BASIC">Funktion Format</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03150000.html?DbPAR=BASIC">Funktion FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03170010.html?DbPAR=BASIC">Funktion FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080503.html?DbPAR=BASIC">Funktion Frac</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020102.html?DbPAR=BASIC">Funktion FreeFile</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090405.html?DbPAR=BASIC">Funktion FreeLibrary</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090406.html?DbPAR=BASIC">Anweisung Function</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090400.html?DbPAR=BASIC">Weitere Anweisungen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140001.html?DbPAR=BASIC">Funktion FV [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080300.html?DbPAR=BASIC">Generieren von Zufallszahlen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020409.html?DbPAR=BASIC">Funktion GetAttr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132500.html?DbPAR=BASIC">Funktion GetDefaultContext</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132100.html?DbPAR=BASIC">Funktion GetGuiType</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131700.html?DbPAR=BASIC">Funktion GetProcessServiceManager</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Funktion GetPathSeparator</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131000.html?DbPAR=BASIC">Funktion GetSolarVersion</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130700.html?DbPAR=BASIC">Funktion GetSystemTicks</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020201.html?DbPAR=BASIC">Anweisung Get</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090301.html?DbPAR=BASIC">Anweisung GoSub...Return</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090302.html?DbPAR=BASIC">Anweisung GoTo</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010302.html?DbPAR=BASIC">Funktion Green</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104400.html?DbPAR=BASIC">Funktion HasUnoInterfaces</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080801.html?DbPAR=BASIC">Funktion Hex</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030201.html?DbPAR=BASIC">Funktion Hour</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090103.html?DbPAR=BASIC">Anweisung IIf</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090101.html?DbPAR=BASIC">Anweisung If...Then...Else</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060300.html?DbPAR=BASIC">Operator Imp</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120401.html?DbPAR=BASIC">Funktion InStr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120411.html?DbPAR=BASIC">Funktion InStrRev [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03160000.html?DbPAR=BASIC">Funktion Input [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010201.html?DbPAR=BASIC">Funktion InputBox</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020202.html?DbPAR=BASIC">Anweisung Input#</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080502.html?DbPAR=BASIC">Funktion Int</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140002.html?DbPAR=BASIC">Funktion IPmt [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140003.html?DbPAR=BASIC">Funktion IRR [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102200.html?DbPAR=BASIC">Funktion IsArray</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102300.html?DbPAR=BASIC">Funktion IsDate</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102400.html?DbPAR=BASIC">Funktion IsEmpty</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104000.html?DbPAR=BASIC">Funktion IsMissing</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102600.html?DbPAR=BASIC">Funktion IsNull</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102700.html?DbPAR=BASIC">Funktion IsNumeric</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102800.html?DbPAR=BASIC">Funktion IsObject</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104500.html?DbPAR=BASIC">Funktion IsUnoStruct</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120315.html?DbPAR=BASIC">Funktion Join</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020410.html?DbPAR=BASIC">Anweisung Kill</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102900.html?DbPAR=BASIC">Funktion LBound</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120302.html?DbPAR=BASIC">Funktion LCase</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120304.html?DbPAR=BASIC">Anweisung LSet</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120305.html?DbPAR=BASIC">Funktion LTrim</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120303.html?DbPAR=BASIC">Funktion Left</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120402.html?DbPAR=BASIC">Funktion Len</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103100.html?DbPAR=BASIC">Anweisung Let</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020203.html?DbPAR=BASIC">Anweisung Line Input #</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020302.html?DbPAR=BASIC">Funktion Loc</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020303.html?DbPAR=BASIC">Funktion Lof</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080202.html?DbPAR=BASIC">Funktion Log</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120306.html?DbPAR=BASIC">Funktion Mid und Anweisung Mid</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030202.html?DbPAR=BASIC">Funktion Minute</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140004.html?DbPAR=BASIC">Funktion MIRR [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020411.html?DbPAR=BASIC">Anweisung MkDir</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070600.html?DbPAR=BASIC">Operator Mod</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030104.html?DbPAR=BASIC">Funktion Month</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03150002.html?DbPAR=BASIC">Funktion MonthName [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010102.html?DbPAR=BASIC">Funktion MsgBox</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010101.html?DbPAR=BASIC">Anweisung MsgBox</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020412.html?DbPAR=BASIC">Anweisung Name</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060400.html?DbPAR=BASIC">Operator Not</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030203.html?DbPAR=BASIC">Funktion Now</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140005.html?DbPAR=BASIC">Funktion NPer [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140006.html?DbPAR=BASIC">Funktion NPV [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080000.html?DbPAR=BASIC">Numerische Funktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080802.html?DbPAR=BASIC">Funktion Oct</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03050500.html?DbPAR=BASIC">Anweisung On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090303.html?DbPAR=BASIC">Anweisungen On...GoSub und On...GoTo</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020103.html?DbPAR=BASIC">Anweisung Open</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103200.html?DbPAR=BASIC">Anweisung Option Base</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103300.html?DbPAR=BASIC">Anweisung Option Explicit</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103350.html?DbPAR=BASIC">Anweisung Option VBASupport</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Anweisung Function)</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060500.html?DbPAR=BASIC">Operator Or</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/partition.html?DbPAR=BASIC">Funktion Partition</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140007.html?DbPAR=BASIC">Funktion Pmt [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140008.html?DbPAR=BASIC">Funktion PPmt [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140009.html?DbPAR=BASIC">Funktion PV [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010103.html?DbPAR=BASIC">Anweisung Print</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103400.html?DbPAR=BASIC">Anweisung Public</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020204.html?DbPAR=BASIC">Anweisung Put</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010304.html?DbPAR=BASIC">Funktion QBColor</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140010.html?DbPAR=BASIC">Funktion Rate [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010305.html?DbPAR=BASIC">Funktion RGB</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120308.html?DbPAR=BASIC">Anweisung RSet</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120309.html?DbPAR=BASIC">Funktion RTrim</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080301.html?DbPAR=BASIC">Anweisung Randomize</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03102101.html?DbPAR=BASIC">Anweisung ReDim</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03010303.html?DbPAR=BASIC">Funktion Red</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090407.html?DbPAR=BASIC">Anweisung Rem</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/replace.html?DbPAR=BASIC">Funktion Replace</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020104.html?DbPAR=BASIC">Anweisung Reset</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120307.html?DbPAR=BASIC">Funktion Right</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020413.html?DbPAR=BASIC">Anweisung RmDir</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080302.html?DbPAR=BASIC">Funktion Rnd</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03170000.html?DbPAR=BASIC">Funktion Round [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030204.html?DbPAR=BASIC">Funktion Second</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020304.html?DbPAR=BASIC">Funktion Seek</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020305.html?DbPAR=BASIC">Anweisung Seek</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090102.html?DbPAR=BASIC">Anweisung Select...Case</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020414.html?DbPAR=BASIC">Anweisung SetAttr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103700.html?DbPAR=BASIC">Anweisung Set</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080701.html?DbPAR=BASIC">Funktion Sgn</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130500.html?DbPAR=BASIC">Funktion Shell</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080103.html?DbPAR=BASIC">Funktion Sin</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140011.html?DbPAR=BASIC">Funktion SLN [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funktionen Space und Spc</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120201.html?DbPAR=BASIC">Funktionen Space und Spc</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120314.html?DbPAR=BASIC">Funktion Split</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080401.html?DbPAR=BASIC">Funktion Sqr</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080400.html?DbPAR=BASIC">Quadratwurzelberechnung</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">Objekt StarDesktop</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103500.html?DbPAR=BASIC">Anweisung Static</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090408.html?DbPAR=BASIC">Anweisung Stop</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120403.html?DbPAR=BASIC">Funktion StrComp</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120103.html?DbPAR=BASIC">Funktion Str</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120412.html?DbPAR=BASIC">Funktion StrReverse [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120202.html?DbPAR=BASIC">Funktion String</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090409.html?DbPAR=BASIC">Anweisung Sub</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090410.html?DbPAR=BASIC">Funktion Switch</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03140012.html?DbPAR=BASIC">Funktion SYD [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080104.html?DbPAR=BASIC">Funktion Tan</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03132200.html?DbPAR=BASIC">Objekt ThisComponent</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030205.html?DbPAR=BASIC">Funktion TimeSerial</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030206.html?DbPAR=BASIC">Funktion TimeValue</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030302.html?DbPAR=BASIC">Anweisung Time</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030303.html?DbPAR=BASIC">Funktion Timer</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03080100.html?DbPAR=BASIC">Trigonometrische Funktionen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120311.html?DbPAR=BASIC">Funktion Trim</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131300.html?DbPAR=BASIC">Funktion TwipsPerPixelX</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03131400.html?DbPAR=BASIC">Funktion TwipsPerPixelY</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090413.html?DbPAR=BASIC">Anweisung Type</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103600.html?DbPAR=BASIC">Funktionen TypeName und VarType</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03103000.html?DbPAR=BASIC">Funktion UBound</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120310.html?DbPAR=BASIC">Funktion UCase</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03120104.html?DbPAR=BASIC">Funktion Val</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130600.html?DbPAR=BASIC">Anweisung Wait</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03130610.html?DbPAR=BASIC">Anweisung WaitUntil</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030105.html?DbPAR=BASIC">Funktion WeekDay</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03150001.html?DbPAR=BASIC">Funktion WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090203.html?DbPAR=BASIC">Anweisung While...Wend</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03090411.html?DbPAR=BASIC">Anweisung With</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03020205.html?DbPAR=BASIC">Anweisung Write</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03060600.html?DbPAR=BASIC">Operator XOR</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03030106.html?DbPAR=BASIC">Funktion Year</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070100.html?DbPAR=BASIC">Operator "-"</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070200.html?DbPAR=BASIC">Operator "*"</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070300.html?DbPAR=BASIC">Operator "+"</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070400.html?DbPAR=BASIC">Operator "/"</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03070500.html?DbPAR=BASIC">Operator "^"</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Erweiterte Basic-Bibliotheken</label><ul>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Bibliothek Tools</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Bibliothek DEPOT</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Bibliothek EURO</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Bibliothek FORMWIZARD</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Bibliothek GIMMICKS</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Bibliothek SCHEDULE</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Bibliothek SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Bibliothek TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Hilfslinien</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/macro_recording.html?DbPAR=BASIC">Makros aufnehmen</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Ändern der Steuerelement-Eigenschaften im Dialog-Editor</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Erstellen von Steuerelementen im Dialog-Editor</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Programmbeispiele für Steuerelemente im Dialog-Editor</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Einen Dialog mit Basic öffnen</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Erstellen eines Basic-Dialogs</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01030400.html?DbPAR=BASIC">Verwalten von Bibliotheken und Modulen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01020100.html?DbPAR=BASIC">Arbeiten mit Variablen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01020200.html?DbPAR=BASIC">Arbeiten mit Objekten</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01030300.html?DbPAR=BASIC">Debuggen von Basic-Programmen</a></li>\
    <li><a target="_top" href="de/text/sbasic/shared/01040000.html?DbPAR=BASIC">Ereignisgesteuerte Makros</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programmierungsbeispiele</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic in Python</a></li>\
    <li><a target="_top" href="de/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Hilfe zu Python-Skripten</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/sbasic/python/main0000.html?DbPAR=BASIC">Python-Skripte</a></li>\
    <li><a target="_top" href="de/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE für Python</a></li>\
    <li><a target="_top" href="de/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organisation von Python-Skripten</a></li>\
    <li><a target="_top" href="de/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interaktive-Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmieren mit Python</label><ul>\
    <li><a target="_top" href="de/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python: Programmierung mit Python</a></li>\
    <li><a target="_top" href="de/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python Beispiele</a></li>\
    <li><a target="_top" href="de/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python in Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Tabellendokumente (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/scalc/main0000.html?DbPAR=CALC">Willkommen bei der Hilfe zu LibreOffice Calc</a></li>\
    <li><a target="_top" href="de/text/scalc/main0503.html?DbPAR=CALC">Leistungsmerkmale von LibreOffice Calc</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/keyboard.html?DbPAR=CALC">Tastenkombinationen (LibreOffice Calc Barrierefreiheit)</a></li>\
    <li><a target="_top" href="de/text/scalc/04/01020000.html?DbPAR=CALC">Tastenkombinationen für Tabellendokumente</a></li>\
    <li><a target="_top" href="de/text/scalc/05/02140000.html?DbPAR=CALC">Fehlercodes in LibreOffice Calc</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060112.html?DbPAR=CALC">Plug-in zu LibreOffice Calc programmieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/main.html?DbPAR=CALC">Anleitungen für LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Befehls- und Menüreferenz</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menüs</label><ul>\
    <li><a target="_top" href="de/text/scalc/main0100.html?DbPAR=CALC">Menüs</a></li>\
    <li><a target="_top" href="de/text/scalc/main0101.html?DbPAR=CALC">Datei</a></li>\
    <li><a target="_top" href="de/text/scalc/main0102.html?DbPAR=CALC">Bearbeiten</a></li>\
    <li><a target="_top" href="de/text/scalc/main0103.html?DbPAR=CALC">Ansicht</a></li>\
    <li><a target="_top" href="de/text/scalc/main0104.html?DbPAR=CALC">Einfügen</a></li>\
    <li><a target="_top" href="de/text/scalc/main0105.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="de/text/scalc/main0116.html?DbPAR=CALC">Tabelle</a></li>\
    <li><a target="_top" href="de/text/scalc/main0112.html?DbPAR=CALC">Daten</a></li>\
    <li><a target="_top" href="de/text/scalc/main0106.html?DbPAR=CALC">Extras</a></li>\
    <li><a target="_top" href="de/text/scalc/main0107.html?DbPAR=CALC">Fenster</a></li>\
    <li><a target="_top" href="de/text/shared/main0108.html?DbPAR=CALC">Hilfe</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Symbolleisten</label><ul>\
    <li><a target="_top" href="de/text/scalc/main0200.html?DbPAR=CALC">Symbolleisten</a></li>\
    <li><a target="_top" href="de/text/scalc/main0202.html?DbPAR=CALC">Symbolleiste Format</a></li>\
    <li><a target="_top" href="de/text/scalc/main0203.html?DbPAR=CALC">Symbolleiste Zeichnungsobjekt-Eigenschaften</a></li>\
    <li><a target="_top" href="de/text/scalc/main0205.html?DbPAR=CALC">Symbolleiste Textformat</a></li>\
    <li><a target="_top" href="de/text/scalc/main0206.html?DbPAR=CALC">Rechenleiste</a></li>\
    <li><a target="_top" href="de/text/scalc/main0208.html?DbPAR=CALC">Statusleiste</a></li>\
    <li><a target="_top" href="de/text/scalc/main0210.html?DbPAR=CALC">Symbolleiste Druckvorschau</a></li>\
    <li><a target="_top" href="de/text/scalc/main0214.html?DbPAR=CALC">Symbolleiste Bild</a></li>\
    <li><a target="_top" href="de/text/scalc/main0218.html?DbPAR=CALC">Symbolleiste Extras</a></li>\
    <li><a target="_top" href="de/text/shared/main0201.html?DbPAR=CALC">Symbolleiste Standard</a></li>\
    <li><a target="_top" href="de/text/shared/main0212.html?DbPAR=CALC">Symbolleiste Datenbank</a></li>\
    <li><a target="_top" href="de/text/shared/main0213.html?DbPAR=CALC">Symbolleiste Formular-Navigation</a></li>\
    <li><a target="_top" href="de/text/shared/main0214.html?DbPAR=CALC">Symbolleiste Abfrageentwurf</a></li>\
    <li><a target="_top" href="de/text/shared/main0226.html?DbPAR=CALC">Symbolleiste Formular-Entwurf</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Funktionen und Operatoren</label><ul>\
    <li><a target="_top" href="de/text/scalc/01/04060000.html?DbPAR=CALC">Funktions-Assistent</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060100.html?DbPAR=CALC">Funktionen nach Kategorie</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060107.html?DbPAR=CALC">Matrixfunktionen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060120.html?DbPAR=CALC">Bitoperationen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060101.html?DbPAR=CALC">Datenbankfunktionen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060102.html?DbPAR=CALC">Datums- und Zeitfunktionen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060103.html?DbPAR=CALC">Finanzmathematische Funktionen Teil Eins</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060119.html?DbPAR=CALC">Finanzmathematische Funktionen Teil Zwei</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060118.html?DbPAR=CALC">Finanzmathematische Funktionen Teil Drei</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060104.html?DbPAR=CALC">Kategorie Information</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060105.html?DbPAR=CALC">Logische Funktionen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060106.html?DbPAR=CALC">Kategorie Mathematik</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060108.html?DbPAR=CALC">Kategorie Statistik</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060181.html?DbPAR=CALC">Statistik Teil 1</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060182.html?DbPAR=CALC">Statistik Teil 2</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060183.html?DbPAR=CALC">Statistik Teil 3</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060184.html?DbPAR=CALC">Statistik Teil 4</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060185.html?DbPAR=CALC">Statistik Teil 5</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060109.html?DbPAR=CALC">Funktionen für Tabellen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060110.html?DbPAR=CALC">Textfunktionen</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060111.html?DbPAR=CALC">Kategorie Plug-in</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060115.html?DbPAR=CALC">Plug-in-Funktionen, Analysefunktionen Teil 1</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060116.html?DbPAR=CALC">Kategorie Plug-in, Liste der Analysis-Funktionen Teil 2</a></li>\
    <li><a target="_top" href="de/text/scalc/01/04060199.html?DbPAR=CALC">Operatoren in LibreOffice Calc</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Benutzerdefinierte Funktionen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Öffnen, Speichern, Importieren, Exportieren und Redigieren</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/webquery.html?DbPAR=CALC">Einfügen externer Daten in Tabellen (Web-Abfrage)</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/html_doc.html?DbPAR=CALC">Tabellen als HTML speichern und öffnen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/csv_formula.html?DbPAR=CALC">Importieren und Exportieren von Textdateien</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redaction.html?DbPAR=CALC">Redigierung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formatierung</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/text_rotate.html?DbPAR=CALC">Text drehen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/text_wrap.html?DbPAR=CALC">Eingabe von mehrzeiligem Text</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatieren von Zahlen als Text</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/super_subscript.html?DbPAR=CALC">Text hochstellen / tiefstellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/row_height.html?DbPAR=CALC">Zeilenhöhe oder Spaltenbreite ändern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Bedingte Formatierung anwenden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Negative Zahlen hervorheben</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Formate per Formel zuweisen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Eingabe von Zahlen mit führenden Nullen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/format_table.html?DbPAR=CALC">Tabellendokumente formatieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/format_value.html?DbPAR=CALC">Formatieren von Zahlen mit Dezimalstellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/value_with_name.html?DbPAR=CALC">Zellen benennen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/table_rotate.html?DbPAR=CALC">Umkehren von Tabellen (transponieren)</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/rename_table.html?DbPAR=CALC">Tabelle umbenennen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx-Jahreszahlen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Zahlen gerundet verwenden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/currency_format.html?DbPAR=CALC">Zellen in Währungsformaten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/autoformat.html?DbPAR=CALC">So verwenden Sie AutoFormat für Tabellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/note_insert.html?DbPAR=CALC">Einfügen und Bearbeiten von Kommentaren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/design.html?DbPAR=CALC">Auswahl von Themen für Tabellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Bruchzahlen eingeben</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtern und Sortieren</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/filters.html?DbPAR=CALC">Anwenden von Filtern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filter: Anwenden von Spezialfiltern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/autofilter.html?DbPAR=CALC">AutoFilter anwenden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/sorted_list.html?DbPAR=CALC">Anwenden von Sortierlisten</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Drucken</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/print_title_row.html?DbPAR=CALC">Zeile oder Spalte auf jeder Seite drucken</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/print_landscape.html?DbPAR=CALC">Tabelle im Querformat drucken</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/print_details.html?DbPAR=CALC">Tabellendetails drucken</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/print_exact.html?DbPAR=CALC">Druckseitenzahl festlegen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Datenbereiche</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/database_define.html?DbPAR=CALC">Definieren von Datenbankbereichen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/database_filter.html?DbPAR=CALC">Zellbereiche filtern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/database_sort.html?DbPAR=CALC">Daten sortieren</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Pivot-Tabelle</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot.html?DbPAR=CALC">Pivot-Tabelle</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Pivot-Tabelle erstellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Pivot-Tabellen löschen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Pivot-Tabellen bearbeiten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Pivot-Tabellen filtern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Ausgabebereich der Pivot-Tabelle wählen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Pivot-Tabellen aktualisieren</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot-Diagramm</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot-Diagramm</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Pivot-Diagramme erstellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Pivot-Diagramme bearbeiten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Pivot-Diagramme filtern</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot-Diagramme aktualisieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Pivot-Diagramme löschen</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Szenarien</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/scenario.html?DbPAR=CALC">Szenarien anwenden</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Referenzen</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adressen und Bezüge, absolut und relativ</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellreferences.html?DbPAR=CALC">Dokumentübergreifende Referenzierung von Zellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Bezüge auf andere Tabellen und URLs</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Zellbezüge beim Ziehen-und-Ablegen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/address_auto.html?DbPAR=CALC">Name als Adressierung erkennen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Anzeigen, Auswählen, Kopieren</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/table_view.html?DbPAR=CALC">Wechseln der Tabellenansicht</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/formula_value.html?DbPAR=CALC">Formeln oder Werte anzeigen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/line_fix.html?DbPAR=CALC">Zeilen oder Spalten als Kopfzeilen fixieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigieren durch Tabellenregister</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Kopieren in mehrere Tabellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cellcopy.html?DbPAR=CALC">Nur sichtbare Zellen kopieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/mark_cells.html?DbPAR=CALC">Mehrere Zellen auswählen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formeln und Berechnungen</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/formulas.html?DbPAR=CALC">Rechnen mit Formeln</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/formula_copy.html?DbPAR=CALC">Formel kopieren</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/formula_enter.html?DbPAR=CALC">Formeln eingeben</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/formula_value.html?DbPAR=CALC">Formeln oder Werte anzeigen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/calculate.html?DbPAR=CALC">Rechnen in Tabellendokumenten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/calc_date.html?DbPAR=CALC">Rechnen mit Datums- und Uhrzeitwerten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/calc_series.html?DbPAR=CALC">Automatische Erstellung von Reihen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Berechnen von Zeitunterschieden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/matrixformula.html?DbPAR=CALC">Matrixformel eingeben</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Schutz</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/cell_protect.html?DbPAR=CALC">Schützen der Zellen vor Änderungen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Aufheben des Zellschutzes</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Verschiedenes</label><ul>\
    <li><a target="_top" href="de/text/scalc/guide/auto_off.html?DbPAR=CALC">Deaktivieren automatischer Änderungen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/consolidate.html?DbPAR=CALC">Konsolidieren der Daten</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/goalseek.html?DbPAR=CALC">Zielwertsuche anwenden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/multioperation.html?DbPAR=CALC">Mehrfachoperationen anwenden</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/multitables.html?DbPAR=CALC">Arbeiten mit mehreren Tabellen</a></li>\
    <li><a target="_top" href="de/text/scalc/guide/validity.html?DbPAR=CALC">Gültigkeit des Zellinhalts</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Diagramme und Schaubilder</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Allgemeine Informationen</label><ul>\
    <li><a target="_top" href="de/text/schart/main0000.html?DbPAR=CHART">Diagramme in LibreOffice</a></li>\
    <li><a target="_top" href="de/text/schart/main0503.html?DbPAR=CHART">Leistungsmerkmale von LibreOffice Diagrammen</a></li>\
    <li><a target="_top" href="de/text/schart/04/01020000.html?DbPAR=CHART">Tastenkombinationen für Diagramme</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ändern der Zuordnung von Microsoft Office-Dokumenttypen</a></li>\
    <li><a target="_top" href="de/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Abgesicherter Modus</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Allgemeine Hilfethemen</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Allgemeine Informationen</label><ul>\
    <li><a target="_top" href="de/text/shared/main0400.html?DbPAR=SHARED">Tastenkombinationen</a></li>\
    <li><a target="_top" href="de/text/shared/00/00000005.html?DbPAR=SHARED">Allgemeines Glossar</a></li>\
    <li><a target="_top" href="de/text/shared/00/00000002.html?DbPAR=SHARED">Internet-Glossar</a></li>\
    <li><a target="_top" href="de/text/shared/guide/accessibility.html?DbPAR=SHARED">Barrierefreiheit in LibreOffice</a></li>\
    <li><a target="_top" href="de/text/shared/guide/keyboard.html?DbPAR=SHARED">Tastatursteuerung (LibreOffice Barrierefreiheit)</a></li>\
    <li><a target="_top" href="de/text/shared/04/01010000.html?DbPAR=SHARED">Allgemeine Tastenkombinationen in LibreOffice</a></li>\
    <li><a target="_top" href="de/text/shared/guide/version_number.html?DbPAR=SHARED">Versionen und Buildnummern</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice und Microsoft Office</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/ms_user.html?DbPAR=SHARED">Arbeiten mit Microsoft Office und LibreOffice</a></li>\
    <li><a target="_top" href="de/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Namen der Leistungsmerkmale in Microsoft Office und LibreOffice - Ein Vergleich</a></li>\
    <li><a target="_top" href="de/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">Hinweise zur Konvertierung von Microsoft Office-Dokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Ändern der Zuordnung von Microsoft Office-Dokumenttypen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice Optionen</label><ul>\
    <li><a target="_top" href="de/text/shared/optionen/01000000.html?DbPAR=SHARED">Optionen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010100.html?DbPAR=SHARED">Eigene Benutzerdaten</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010200.html?DbPAR=SHARED">Allgemein</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010300.html?DbPAR=SHARED">Pfade</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010400.html?DbPAR=SHARED">Linguistik</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010600.html?DbPAR=SHARED">Allgemein</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010700.html?DbPAR=SHARED">Schriftarten...</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010800.html?DbPAR=SHARED">Anzeige</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01010900.html?DbPAR=SHARED">Druckoptionen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01012000.html?DbPAR=SHARED">Anwendungsfarben</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01013000.html?DbPAR=SHARED">Barrierefreiheit</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/java.html?DbPAR=SHARED">Erweitert</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Experteneinstellungen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic-IDE</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/opencl.html?DbPAR=SHARED">OpenCL</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01020000.html?DbPAR=SHARED">Optionen Laden/Speichern</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01030000.html?DbPAR=SHARED">Optionen Internet</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01040000.html?DbPAR=SHARED">Optionen Textdokument</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01050000.html?DbPAR=SHARED">Optionen HTML-Dokument</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01060000.html?DbPAR=SHARED">Optionen für Tabellendokumente</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01070000.html?DbPAR=SHARED">Optionen Präsentation</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01080000.html?DbPAR=SHARED">Zeichnungsoptionen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01090000.html?DbPAR=SHARED">Formel</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01110000.html?DbPAR=SHARED">Optionen Diagramm</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA-Eigenschaften</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01140000.html?DbPAR=SHARED">Sprachen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01150000.html?DbPAR=SHARED">Spracheinstellungsoptionen</a></li>\
    <li><a target="_top" href="de/text/shared/optionen/01160000.html?DbPAR=SHARED">Optionen Datenquellen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Assistenten</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01000000.html?DbPAR=SHARED">Assistent</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Brief-Assistent</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01010000.html?DbPAR=SHARED">Brief-Assistent</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Fax-Assistent</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01020000.html?DbPAR=SHARED">Fax-Assistent</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Tagesordnungs-Assistent</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01040000.html?DbPAR=SHARED">Tagesordnungs-Assistent</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML Export-Assistent</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML-Export</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Dokument Konverter-Assistent</label><ul>\
    <li><a target="_top" href="de/text/shared/autopi/01130000.html?DbPAR=SHARED">Dokumenten-Konverter-Assistent</a></li>\
			</ul></li>\
    <li><a target="_top" href="de/text/shared/autopi/01150000.html?DbPAR=SHARED">Euro-Konverter-Assistent</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">LibreOffice konfigurieren</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/configure_overview.html?DbPAR=SHARED">Anpassen von LibreOffice</a></li>\
    <li><a target="_top" href="de/text/shared/01/packagemanager.html?DbPAR=SHARED">Extension-Manager</a></li>\
    <li><a target="_top" href="de/text/shared/guide/flat_icons.html?DbPAR=SHARED">Symbolansicht ändern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Einfügen von Schaltflächen in Symbolleisten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/workfolder.html?DbPAR=SHARED">Arbeitsverzeichnis ändern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/standard_template.html?DbPAR=SHARED">Standardvorlage ändern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Adressbuch anmelden</a></li>\
    <li><a target="_top" href="de/text/shared/guide/formfields.html?DbPAR=SHARED">Schaltfläche einfügen und bearbeiten</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Mit der Benutzeroberfläche arbeiten</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigation für schnelles Erreichen eines Objekts</a></li>\
    <li><a target="_top" href="de/text/shared/guide/navigator.html?DbPAR=SHARED">Navigator für Dokumentübersicht</a></li>\
    <li><a target="_top" href="de/text/shared/guide/autohide.html?DbPAR=SHARED">Fenster ein-/ausblenden und andocken</a></li>\
    <li><a target="_top" href="de/text/shared/guide/textmode_change.html?DbPAR=SHARED">Umschalten zwischen Einfüge- und Überschreibmodus</a></li>\
    <li><a target="_top" href="de/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Arbeiten mit Symbolleisten</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digitale Signaturen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/digital_signatures.html?DbPAR=SHARED">Über digitale Signaturen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Digitale Signaturen anwenden</a></li>\
    <li><a target="_top" href="de/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Digitale Signaturen beim PDF-Export</a></li>\
    <li><a target="_top" href="de/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Bestehendes PDF signieren...</a></li>\
    <li><a target="_top" href="de/text/swriter/01/addsignatureline.html?DbPAR=SHARED">Eine Unterschriftzeile in Textdokumente einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/01/signsignatureline.html?DbPAR=SHARED">Unterschriftzeile signieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Drucken, Faxen, Senden</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/labels_database.html?DbPAR=SHARED">Drucken von Adressetiketten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Drucken in Schwarzweiß</a></li>\
    <li><a target="_top" href="de/text/shared/guide/email.html?DbPAR=SHARED">Versenden von Dokumenten als E-Mail</a></li>\
    <li><a target="_top" href="de/text/shared/guide/fax.html?DbPAR=SHARED">Faxe versenden und LibreOffice zum Faxen konfigurieren</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Ziehen-und-Ablegen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop.html?DbPAR=SHARED">Ziehen-und-Ablegen innerhalb eines LibreOffice-Dokuments</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Verschieben und Kopieren von Text in Dokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Tabellenbereiche in Textdokumente kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafik zwischen Dokumenten kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Grafik aus der Gallery kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Ziehen-und-Ablegen aus der Datenquellenansicht</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Kopieren-und-Einfügen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Zeichnungsobjekte in andere Dokumente kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Grafik zwischen Dokumenten kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Grafik aus der Gallery kopieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Tabellenbereiche in Textdokumente kopieren</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Diagramme und Schaubilder</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/chart_insert.html?DbPAR=SHARED">Diagramm einfügen</a></li>\
    <li><a target="_top" href="de/text/schart/main0000.html?DbPAR=SHARED">Diagramme in LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Laden, Speichern, Im-, Exportieren und PDF erzeugen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/doc_open.html?DbPAR=SHARED">Öffnen von Dokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/import_ms.html?DbPAR=SHARED">Öffnen von Dokumenten aus Fremdformaten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/doc_save.html?DbPAR=SHARED">Speichern von Dokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Dokument automatisch speichern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/export_ms.html?DbPAR=SHARED">Dokumente in Fremdformaten speichern</a></li>\
    <li><a target="_top" href="de/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exportieren als PDF</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Import und Export von Daten im Textformat</a></li>\
    <li><a target="_top" href="de/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Verknüpfungen und Verweise</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Hyperlink einfügen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Relative und absolute Links</a></li>\
    <li><a target="_top" href="de/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Hyperlinks bearbeiten</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Dokumentenänderungen verfolgen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Vergleichen verschiedener Dokumentversionen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Versionen zusammenführen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Aufzeichnen von Änderungen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining.html?DbPAR=SHARED">Änderungen aufzeichnen und anzeigen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Änderungen akzeptieren oder verwerfen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Versionsverwaltung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Etiketten und Visitenkarten</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/labels.html?DbPAR=SHARED">Etiketten und Visitenkarten erstellen und drucken</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Externe Daten einfügen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/copytable2application.html?DbPAR=SHARED">Einfügen von Daten aus Tabellendokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/copytext2application.html?DbPAR=SHARED">Einfügen von Daten aus Textdokumenten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Einfügen, Bearbeiten und Speichern von Bitmaps</a></li>\
    <li><a target="_top" href="de/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Grafik aus einem Dokument in die Gallery einfügen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Automatische Funktionen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Ausschalten der automatischen URL-Erkennung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Suchen und Ersetzen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/data_search2.html?DbPAR=SHARED">Suchen mit einem Formular-Filter</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_search.html?DbPAR=SHARED">Suchen in Tabellen und Textdokumenten mit Formularfunktionen</a></li>\
    <li><a target="_top" href="de/text/shared/01/02100001.html?DbPAR=SHARED">Liste der regulären Ausdrücke</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Anleitungen</label><ul>\
    <li><a target="_top" href="de/text/shared/guide/linestyles.html?DbPAR=SHARED">Linienstile anwenden</a></li>\
    <li><a target="_top" href="de/text/shared/guide/text_color.html?DbPAR=SHARED">Ändern der Textfarbe</a></li>\
    <li><a target="_top" href="de/text/shared/guide/change_title.html?DbPAR=SHARED">Titel eines Dokuments ändern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/round_corner.html?DbPAR=SHARED">Runde Ecken erzeugen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/background.html?DbPAR=SHARED">Einstellen von Hintergrundfarben und Hintergrundbildern</a></li>\
    <li><a target="_top" href="de/text/shared/guide/lineend_define.html?DbPAR=SHARED">Linienende definieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Linienstil definieren</a></li>\
    <li><a target="_top" href="de/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Grafikobjekte bearbeiten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/line_intext.html?DbPAR=SHARED">Linie in den Text zeichnen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/aaa_start.html?DbPAR=SHARED">Erste Schritte</a></li>\
    <li><a target="_top" href="de/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Einfügen eines Objektes aus der Gallery</a></li>\
    <li><a target="_top" href="de/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Einfügen von geschützten Leerzeichen, geschützten Bindestrichen und weichen Trennzeichen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Sonderzeichen einfügen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/tabs.html?DbPAR=SHARED">Tabulator einfügen und bearbeiten</a></li>\
    <li><a target="_top" href="de/text/shared/guide/protection.html?DbPAR=SHARED">Schützen von Inhalten in LibreOffice</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Aufzeichnung schützen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Auswahl des maximalen Druckbereichs</a></li>\
    <li><a target="_top" href="de/text/shared/guide/measurement_units.html?DbPAR=SHARED">Maßeinheiten wählen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/language_select.html?DbPAR=SHARED">Sprache im Dokument wählen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Tabellenentwurf</a></li>\
    <li><a target="_top" href="de/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Nummerierung/Aufzählung für einzelne Absätze ausschalten</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Datenbankenfunktionalität (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Allgemeine Informationen</label><ul>\
    <li><a target="_top" href="de/text/shared/explorer/database/main.html?DbPAR=SHARED">LibreOffice-Datenbank</a></li>\
    <li><a target="_top" href="de/text/shared/guide/database_main.html?DbPAR=SHARED">Datenbankübersicht</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_new.html?DbPAR=SHARED">Erstellen einer neuen Datenbank</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_tables.html?DbPAR=SHARED">Arbeiten mit Tabellen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_queries.html?DbPAR=SHARED">Arbeiten mit Abfragen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_forms.html?DbPAR=SHARED">Arbeiten mit Formularen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_reports.html?DbPAR=SHARED">Berichte erstellen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_register.html?DbPAR=SHARED">Registrieren und Löschen einer Datenbank</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_im_export.html?DbPAR=SHARED">Importieren und Exportieren von Daten in Base</a></li>\
    <li><a target="_top" href="de/text/shared/guide/data_enter_sql.html?DbPAR=SHARED">SQL-Befehl direkt ausführen</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Präsentationen (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/simpress/main0000.html?DbPAR=IMPRESS">Willkommen bei der Hilfe zu LibreOffice Impress</a></li>\
    <li><a target="_top" href="de/text/simpress/main0503.html?DbPAR=IMPRESS">Funktionsumfang von LibreOffice Impress</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Arbeiten mit Tastenkombinationen in LibreOffice Impress</a></li>\
    <li><a target="_top" href="de/text/simpress/04/01020000.html?DbPAR=IMPRESS">Tastenkombinationen für LibreOffice Impress</a></li>\
    <li><a target="_top" href="de/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Tastenkombinationen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/main.html?DbPAR=IMPRESS">Anleitungen für LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Befehls- und Menüreferenz</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menüs</label><ul>\
    <li><a target="_top" href="de/text/simpress/main0100.html?DbPAR=IMPRESS">Menüs</a></li>\
    <li><a target="_top" href="de/text/simpress/main0101.html?DbPAR=IMPRESS">Datei</a></li>\
    <li><a target="_top" href="de/text/simpress/main_edit.html?DbPAR=IMPRESS">Bearbeiten</a></li>\
    <li><a target="_top" href="de/text/simpress/main0103.html?DbPAR=IMPRESS">Ansicht</a></li>\
    <li><a target="_top" href="de/text/simpress/main0104.html?DbPAR=IMPRESS">Einfügen</a></li>\
    <li><a target="_top" href="de/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="de/text/simpress/main_slide.html?DbPAR=IMPRESS">Folie</a></li>\
    <li><a target="_top" href="de/text/simpress/main0114.html?DbPAR=IMPRESS">Bildschirmpräsentation</a></li>\
    <li><a target="_top" href="de/text/simpress/main_tools.html?DbPAR=IMPRESS">Extras</a></li>\
    <li><a target="_top" href="de/text/simpress/main0107.html?DbPAR=IMPRESS">Fenster</a></li>\
    <li><a target="_top" href="de/text/shared/main0108.html?DbPAR=IMPRESS">Hilfe</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Symbolleisten</label><ul>\
    <li><a target="_top" href="de/text/simpress/main0200.html?DbPAR=IMPRESS">Symbolleisten</a></li>\
    <li><a target="_top" href="de/text/simpress/main0202.html?DbPAR=IMPRESS">Symbolleiste Linie und Füllung</a></li>\
    <li><a target="_top" href="de/text/simpress/main0203.html?DbPAR=IMPRESS">Symbolleiste Textformat</a></li>\
    <li><a target="_top" href="de/text/simpress/main0204.html?DbPAR=IMPRESS">Symbolleiste Folienansicht</a></li>\
    <li><a target="_top" href="de/text/simpress/main0206.html?DbPAR=IMPRESS">Statusleiste</a></li>\
    <li><a target="_top" href="de/text/simpress/main0209.html?DbPAR=IMPRESS">Lineale</a></li>\
    <li><a target="_top" href="de/text/simpress/main0210.html?DbPAR=IMPRESS">Symbolleiste Zeichnung</a></li>\
    <li><a target="_top" href="de/text/simpress/main0211.html?DbPAR=IMPRESS">Symbolleiste Gliederung</a></li>\
    <li><a target="_top" href="de/text/simpress/main0212.html?DbPAR=IMPRESS">Symbolleiste Foliensortiertisch</a></li>\
    <li><a target="_top" href="de/text/simpress/main0213.html?DbPAR=IMPRESS">Symbolleiste Optionen</a></li>\
    <li><a target="_top" href="de/text/simpress/main0214.html?DbPAR=IMPRESS">Symbolleiste Bild</a></li>\
    <li><a target="_top" href="de/text/shared/main0201.html?DbPAR=IMPRESS">Symbolleiste Standard</a></li>\
    <li><a target="_top" href="de/text/shared/main0213.html?DbPAR=IMPRESS">Symbolleiste Formular-Navigation</a></li>\
    <li><a target="_top" href="de/text/shared/main0226.html?DbPAR=IMPRESS">Symbolleiste Formular-Entwurf</a></li>\
    <li><a target="_top" href="de/text/shared/main0227.html?DbPAR=IMPRESS">Symbolleiste Punkte bearbeiten</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Öffnen, Speichern, Importieren, Exportieren und Redigieren</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Speichern von Präsentationen im HTML-Format</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/html_import.html?DbPAR=IMPRESS">HTML-Seite in Präsentation importieren</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Laden von Farb-, Farbverlaufs- und Schraffurtabellen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportieren von Animationen in das GIF-Format</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Einbinden von Tabellendokumenten in Folien</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafiken einfügen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Kopieren von Folien aus anderen Präsentationen</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redigierung</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formatierung</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Laden von Farb-, Farbverlaufs- und Schraffurtabellen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Laden von Linienstil- und Linienspitzentabellen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Erstellen benutzerdefinierter Farben</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Erzeugen von Farbverlaufsfüllungen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Farben ersetzen mit der Pipette</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Anordnen, Ausrichten und Verteilen von Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/background.html?DbPAR=IMPRESS">Ändern der Hintergrundfüllung von Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/footer.html?DbPAR=IMPRESS">Einfügen von Kopf- oder Fußzeilen in alle Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Ändern und Hinzufügen einer Masterfolie</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Verschieben von Objekten</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Drucken</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/printing.html?DbPAR=IMPRESS">Drucken von Präsentationen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Drucken einer an ein Papierformat angepassten Folie</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effekte</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Exportieren von Animationen in das GIF-Format</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animieren von Objekten in Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animation des Folienübergangs</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Überblendung zwischen zwei Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Animiertes GIF-Bild erstellen</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objekte, Grafiken und Bitmaps</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Kombinieren von Objekten und Bilden von Formen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Gruppieren von Objekten</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Sektoren und Segmente zeichnen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Objekt duplizieren</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Drehen von Objekten</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">3D-Objekte zusammensetzen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Verbinden von Linien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Umwandeln von Textzeichen in Zeichnungsobjekte</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Konvertieren von Bitmap-Bildern in Vektorgrafiken</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Umwandeln von 2D-Objekten in Kurven, Polygone und 3D-Objekte</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Laden von Linienstil- und Linienspitzentabellen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Beliebige Kurven zeichnen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Bearbeiten von Kurven</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Grafiken einfügen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Einbinden von Tabellendokumenten in Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Verschieben von Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Auswählen von darunter liegenden Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Erstellen von Flussdiagrammen</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Präsentationen</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Hinzufügen von Text</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Umwandeln von Textzeichen in Zeichnungsobjekte</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Anzeigen</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Ändern der Folienreihenfolge</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoomen mit der Tastatur</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Bildschirmpräsentationen</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/show.html?DbPAR=IMPRESS">Anzeigen einer Bildschirmpräsentation</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Presenter Console verwenden</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Anleitung Impress-Fernsteuerung</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/individual.html?DbPAR=IMPRESS">Erstellen einer benutzerdefinierten Bildschirmpräsentation</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Folienwechsel mit Zeitnahme</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formeln (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Allgemeine Informationen und Verwendung der Benutzerschnittstelle</label><ul>\
    <li><a target="_top" href="de/text/smath/main0000.html?DbPAR=MATH">Willkommen bei der Hilfe zu LibreOffice Math</a></li>\
    <li><a target="_top" href="de/text/smath/main0503.html?DbPAR=MATH">Funktionsumfang von LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formelelemente</label><ul>\
    <li><a target="_top" href="de/text/smath/01/03090100.html?DbPAR=MATH">Unäre/Binäre Operatoren</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090200.html?DbPAR=MATH">Relationen</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090800.html?DbPAR=MATH">Mengenoperationen</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090400.html?DbPAR=MATH">Funktionen</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090300.html?DbPAR=MATH">Operatoren</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090600.html?DbPAR=MATH">Attribute</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090500.html?DbPAR=MATH">Klammern</a></li>\
    <li><a target="_top" href="de/text/smath/01/03090700.html?DbPAR=MATH">Formatierung</a></li>\
    <li><a target="_top" href="de/text/smath/01/03091600.html?DbPAR=MATH">Sonstiges</a></li>\
            </ul></li>\
    <li><a target="_top" href="de/text/smath/guide/main.html?DbPAR=MATH">Anleitungen für LibreOffice Math</a></li>\
    <li><a target="_top" href="de/text/smath/guide/keyboard.html?DbPAR=MATH">Tastatursteuerung (LibreOffice Math Barrierefreiheit)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Befehls- und Menüreferenz</label><ul>\
    <li><a target="_top" href="de/text/smath/main0100.html?DbPAR=MATH">Menüs</a></li>\
    <li><a target="_top" href="de/text/smath/main0200.html?DbPAR=MATH">Symbolleisten</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Mit Formeln arbeiten</label><ul>\
    <li><a target="_top" href="de/text/smath/guide/align.html?DbPAR=MATH">Formelteile manuell ausrichten</a></li>\
    <li><a target="_top" href="de/text/smath/guide/attributes.html?DbPAR=MATH">Standardattribute ändern</a></li>\
    <li><a target="_top" href="de/text/smath/guide/brackets.html?DbPAR=MATH">Formelteile in Klammern zusammenfassen</a></li>\
    <li><a target="_top" href="de/text/smath/guide/comment.html?DbPAR=MATH">Kommentar eingeben</a></li>\
    <li><a target="_top" href="de/text/smath/guide/newline.html?DbPAR=MATH">Zeilenumbruch eingeben</a></li>\
    <li><a target="_top" href="de/text/smath/guide/parentheses.html?DbPAR=MATH">Klammern eingeben</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="02"><label for="02">Textdokumente (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/swriter/main0000.html?DbPAR=WRITER">Willkommen bei der Hilfe zu LibreOffice Writer</a></li>\
    <li><a target="_top" href="de/text/swriter/main0503.html?DbPAR=WRITER">Leistungsmerkmale von LibreOffice Writer</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/main.html?DbPAR=WRITER">Anleitungen für LibreOffice Writer</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Andocken und Skalieren von Fenstern</a></li>\
    <li><a target="_top" href="de/text/swriter/04/01020000.html?DbPAR=WRITER">Tastenkombinationen für LibreOffice Writer</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/words_count.html?DbPAR=WRITER">Zählen von Wörtern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/keyboard.html?DbPAR=WRITER">Verwenden von Tastaturkombinationen (LibreOffice Writer Barrierefreiheit)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Befehls- und Menüreferenz</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menüs</label><ul>\
    <li><a target="_top" href="de/text/swriter/main0100.html?DbPAR=WRITER">Menüs</a></li>\
    <li><a target="_top" href="de/text/swriter/main0101.html?DbPAR=WRITER">Datei</a></li>\
    <li><a target="_top" href="de/text/swriter/main0102.html?DbPAR=WRITER">Bearbeiten</a></li>\
    <li><a target="_top" href="de/text/swriter/main0103.html?DbPAR=WRITER">Ansicht</a></li>\
    <li><a target="_top" href="de/text/swriter/main0104.html?DbPAR=WRITER">Einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/main0105.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="de/text/swriter/main0115.html?DbPAR=WRITER">Vorlagen</a></li>\
    <li><a target="_top" href="de/text/swriter/main0110.html?DbPAR=WRITER">Tabelle</a></li>\
    <li><a target="_top" href="de/text/swriter/main0120.html?DbPAR=WRITER">Menü Formular</a></li>\
    <li><a target="_top" href="de/text/swriter/main0106.html?DbPAR=WRITER">Extras</a></li>\
    <li><a target="_top" href="de/text/swriter/main0107.html?DbPAR=WRITER">Fenster</a></li>\
    <li><a target="_top" href="de/text/shared/main0108.html?DbPAR=WRITER">Hilfe</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Symbolleisten</label><ul>\
    <li><a target="_top" href="de/text/swriter/main0200.html?DbPAR=WRITER">Symbolleisten</a></li>\
    <li><a target="_top" href="de/text/swriter/main0202.html?DbPAR=WRITER">Symbolleiste Format</a></li>\
    <li><a target="_top" href="de/text/swriter/main0203.html?DbPAR=WRITER">Symbolleiste Bild</a></li>\
    <li><a target="_top" href="de/text/swriter/main0204.html?DbPAR=WRITER">Symbolleiste Tabelle</a></li>\
    <li><a target="_top" href="de/text/swriter/main0205.html?DbPAR=WRITER">Symbolleiste Zeichnungsobjekt-Eigenschaften</a></li>\
    <li><a target="_top" href="de/text/swriter/main0206.html?DbPAR=WRITER">Symbolleiste Aufzählungszeichen und Nummerierung</a></li>\
    <li><a target="_top" href="de/text/swriter/main0208.html?DbPAR=WRITER">Statusleiste</a></li>\
    <li><a target="_top" href="de/text/swriter/main0210.html?DbPAR=WRITER">Druckvorschau</a></li>\
    <li><a target="_top" href="de/text/swriter/main0213.html?DbPAR=WRITER">Lineale</a></li>\
    <li><a target="_top" href="de/text/swriter/main0214.html?DbPAR=WRITER">Rechenleiste</a></li>\
    <li><a target="_top" href="de/text/swriter/main0215.html?DbPAR=WRITER">Symbolleiste Rahmen</a></li>\
    <li><a target="_top" href="de/text/swriter/main0216.html?DbPAR=WRITER">Symbolleiste OLE-Objekt</a></li>\
    <li><a target="_top" href="de/text/swriter/main0220.html?DbPAR=WRITER">Symbolleiste Textobjekt</a></li>\
    <li><a target="_top" href="de/text/shared/main0201.html?DbPAR=WRITER">Symbolleiste Standard</a></li>\
    <li><a target="_top" href="de/text/shared/main0212.html?DbPAR=WRITER">Symbolleiste Datenbank</a></li>\
    <li><a target="_top" href="de/text/shared/main0213.html?DbPAR=WRITER">Symbolleiste Formular-Navigation</a></li>\
    <li><a target="_top" href="de/text/shared/main0214.html?DbPAR=WRITER">Symbolleiste Abfrageentwurf</a></li>\
    <li><a target="_top" href="de/text/shared/main0226.html?DbPAR=WRITER">Symbolleiste Formular-Entwurf</a></li>\
    <li><a target="_top" href="de/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Symbolleiste LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Textdokumente erstellen</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigation und Auswahl per Tastatur</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Arbeiten mit dem Direkt-Cursor</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Grafiken in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Einfügen von Grafiken</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Einfügen einer Grafik aus einer Datei</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Einfügen von Grafiken aus der Gallery mittels Ziehen-und-Ablegen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Einfügen eines gescannten Bildes</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Calc-Diagramme in Textdokumente einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Grafik einfügen aus LibreOffice Draw oder Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tabellen in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ein- oder Ausschalten der Zahlenerkennung in Tabellen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/tablemode.html?DbPAR=WRITER">Ändern von Zeilen und Spalten mit der Tastatur</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/table_delete.html?DbPAR=WRITER">Löschen von Tabellen oder Tabelleninhalten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/table_insert.html?DbPAR=WRITER">Tabelle einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Wiederholen von Tabellenüberschriften auf Folgeseiten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Ändern der Größe von Zeilen und Spalten einer Texttabelle</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objekte in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Positionieren von Objekten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/wrap.html?DbPAR=WRITER">Textfluss um Objekte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Bereiche und Rahmen in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/sections.html?DbPAR=WRITER">Arbeiten mit Bereichen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_frame.html?DbPAR=WRITER">Einfügen, Bearbeiten und Verketten von Rahmen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/section_edit.html?DbPAR=WRITER">Bereich bearbeiten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/section_insert.html?DbPAR=WRITER">Bereich einfügen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Inhalts- und Stichwortverzeichnisse</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitelnummerierung</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Benutzerdefinierte Verzeichnisse</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Inhaltsverzeichnis erstellen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_index.html?DbPAR=WRITER">Erzeugen von Stichwortverzeichnissen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Verzeichnisse für mehrere Dokumente</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Erzeugen eines Literaturverzeichnisses</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Verzeichniseintrag bearbeiten oder löschen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Aktualisieren, Bearbeiten und Löschen von Inhaltsverzeichnissen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Index- beziehungsweise Inhaltsverzeichniseinträge definieren</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatierung eines Stichwort- oder Inhaltsverzeichnisses</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Felder in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/fields.html?DbPAR=WRITER">Über Feldbefehle</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/fields_date.html?DbPAR=WRITER">Einfügen von fixen oder variablen Datumsfeldern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/field_convert.html?DbPAR=WRITER">Konvertieren von Feldbefehlen in Text</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">In Textdokumenten navigieren</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Verschieben und Kopieren von Text in Dokumenten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Dokumente mit dem Navigator neu anordnen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Einfügen von Hyperlinks mit dem Navigator</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigator für Textdokumente</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Berechnungen in Textdokumenten</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Tabellenübergreifende Berechnungen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/calculate.html?DbPAR=WRITER">Berechnungen in Textdokumenten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Berechnen von Formeln in Textdokumenten und Einfügen der Ergebnisse</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Summen von Tabellenzellen berechnen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Berechnen komplexer Formeln in Textdokumenten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Anzeigen der Ergebnisse von Tabellenberechnungen in einer anderen Tabelle</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Textdokumente formatieren</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Dokumentvorlagen und Formatvorlagen</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Dokumentvorlagen und Formatvorlagen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Abwechselnde Seitenvorlagen auf geraden und ungeraden Seiten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/change_header.html?DbPAR=WRITER">Eine auf der aktuellen Seite beruhende Seitenvorlage erstellen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/load_styles.html?DbPAR=WRITER">Verwenden von Formatvorlagen aus anderen Dokumenten oder Dokumentvorlagen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Erstellen neuer Vorlagen aus einer Auswahl</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Formatvorlage aus Selektion aktualisieren</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/template_create.html?DbPAR=WRITER">Erstellen einer Dokumentvorlage</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/template_default.html?DbPAR=WRITER">Ändern der Standardvorlage</a></li>\
			</ul></li>\
    <li><a target="_top" href="de/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Ändern der Seitenausrichtung (Quer- oder Hochformat)</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_capital.html?DbPAR=WRITER">Groß- und Kleinschreibung von Text ändern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Verstecken von Text</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definieren unterschiedlicher Kopf- und Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Einfügen von Kapitelnamen und -nummern in Kopf-/Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Anwenden von Textformatierung während der Eingabe</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/reset_format.html?DbPAR=WRITER">Zurücksetzen von Zeichenattributen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Anwenden von Vorlagen im Gießkannenmodus</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/wrap.html?DbPAR=WRITER">Textfluss um Objekte</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Zentrieren von Text mittels Rahmen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Hervorheben von Text</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Text drehen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/page_break.html?DbPAR=WRITER">Seitenumbruch einfügen und löschen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Erstellen und Anwenden von Seitenvorlagen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/subscript.html?DbPAR=WRITER">Text hochstellen und tiefstellen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Besondere Textelemente</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/captions.html?DbPAR=WRITER">Beschriftungen verwenden</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Bedingter Text</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Bedingter Text für Seitenanzahlen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/fields_date.html?DbPAR=WRITER">Einfügen von fixen oder variablen Datumsfeldern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Einfügen von Eingabefeldern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Seitennummer der Folgeseite einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Seitennummern in Fußzeile einfügen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Verstecken von Text</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Definieren unterschiedlicher Kopf- und Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Einfügen von Kapitelnamen und -nummern in Kopf-/Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Benutzerdaten in Feldern beziehungsweise Bedingungen abfragen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Einfügen und Bearbeiten von Fuß-/Endnoten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Abstand zwischen Fuß-/Endnoten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_footer.html?DbPAR=WRITER">Informationen zu Kopf- und Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatierung von Kopf- und Fußzeilen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animieren von Text</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Erstellen eines Serienbriefs</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Automatische Funktionen</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Hinzufügen von Ausnahmen zur AutoKorrektur-Liste</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/autotext.html?DbPAR=WRITER">Textbausteine als AutoText verwenden</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Anlegen von nummerierten beziehungsweise Aufzählungslisten während der Eingabe</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/auto_off.html?DbPAR=WRITER">Ausschalten der AutoKorrektur</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatische Rechtschreibprüfung</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Ein- oder Ausschalten der Zahlenerkennung in Tabellen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Silbentrennung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Aufzählungszeichen und Nummerierung</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Einfügen von Kapitelnummern in Beschriftungen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Anlegen von nummerierten beziehungsweise Aufzählungslisten während der Eingabe</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Kapitelnummerierung</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Ändern der Gliederungsebene von nummerierten und Aufzählungslisten</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Kombinieren von nummerierten Listen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Hinzufügen von Zeilennummern</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Ändern der Nummerierung in nummerierten Listen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Definieren von Nummernkreisen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Aktivieren der Nummerierung</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Nummerierung und Nummerierungsvorlagen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Hinzufügen von Aufzählungszeichen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Rechtschreibprüfung, Thesaurus und Sprachen</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Automatische Rechtschreibprüfung</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Entfernen von Wörtern aus einem Benutzerwörterbuch</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Thesaurus</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Rechtschreib- und Grammatikprüfung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Tipps zur Problembehandlung</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Einfügen von Text vor einer Tabelle am Seitenanfang</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Zu bestimmten Textmarken springen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Öffnen, Speichern, Importieren, Exportieren und Redigieren</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/send2html.html?DbPAR=WRITER">Speichern von Textdokumenten im HTML-Format</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Einfügen eines ganzen Textdokuments</a></li>\
    <li><a target="_top" href="de/text/shared/guide/redaction.html?DbPAR=WRITER">Redigierung</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Globaldokumente</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Global- und Teildokumente</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Verknüpfungen und Verweise</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/references.html?DbPAR=WRITER">Einfügen von Querverweisen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Einfügen von Hyperlinks mit dem Navigator</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Drucken</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Druckerschächte auswählen</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/print_preview.html?DbPAR=WRITER">Druckvorschau vor dem Druck</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/print_small.html?DbPAR=WRITER">Drucken mehrerer Seiten auf ein Blatt</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Erstellen und Anwenden von Seitenvorlagen</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Suchen und Ersetzen</label><ul>\
    <li><a target="_top" href="de/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Verwendung von regulären Ausdrücken bei der Textsuche</a></li>\
    <li><a target="_top" href="de/text/shared/01/02100001.html?DbPAR=WRITER">Liste der regulären Ausdrücke</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML-Dokumente (Writer Web)</label><ul>\
    <li><a target="_top" href="de/text/shared/07/09000000.html?DbPAR=WRITER">Webseiten</a></li>\
    <li><a target="_top" href="de/text/shared/02/01170700.html?DbPAR=WRITER">HTML-Filter und -Formulare</a></li>\
    <li><a target="_top" href="de/text/swriter/guide/send2html.html?DbPAR=WRITER">Speichern von Textdokumenten im HTML-Format</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Zeichnungen (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Allgemeine Informationen und Verwendung der Benutzeroberfläche</label><ul>\
    <li><a target="_top" href="de/text/sdraw/main0000.html?DbPAR=DRAW">Willkommen bei der Hilfe zu LibreOffice Draw</a></li>\
    <li><a target="_top" href="de/text/sdraw/main0503.html?DbPAR=DRAW">Leistungsmerkmale von LibreOffice Draw</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Tastatursteuerung für Zeichnungsobjekte</a></li>\
    <li><a target="_top" href="de/text/sdraw/04/01020000.html?DbPAR=DRAW">Tastenkombinationen für Zeichnungen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/main.html?DbPAR=DRAW">Anleitung für die Arbeit mit LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Befehls- und Menüreferenz</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menüs</label><ul>\
    <li><a target="_top" href="de/text/sdraw/main0100.html?DbPAR=DRAW">Menüs</a></li>\
    <li><a target="_top" href="de/text/sdraw/main0101.html?DbPAR=DRAW">Datei</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_edit.html?DbPAR=DRAW">Bearbeiten</a></li>\
    <li><a target="_top" href="de/text/sdraw/main0103.html?DbPAR=DRAW">Ansicht</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_insert.html?DbPAR=DRAW">Einfügen</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_page.html?DbPAR=DRAW">Folie</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_shape.html?DbPAR=DRAW">Form</a></li>\
    <li><a target="_top" href="de/text/sdraw/main_tools.html?DbPAR=DRAW">Extras</a></li>\
    <li><a target="_top" href="de/text/simpress/main0107.html?DbPAR=DRAW">Fenster</a></li>\
    <li><a target="_top" href="de/text/shared/main0108.html?DbPAR=DRAW">Hilfe</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Symbolleisten</label><ul>\
    <li><a target="_top" href="de/text/sdraw/main0200.html?DbPAR=DRAW">Symbolleisten</a></li>\
    <li><a target="_top" href="de/text/sdraw/main0210.html?DbPAR=DRAW">Symbolleiste Zeichnung</a></li>\
    <li><a target="_top" href="de/text/sdraw/main0213.html?DbPAR=DRAW">Symbolleiste Optionen</a></li>\
    <li><a target="_top" href="de/text/shared/main0201.html?DbPAR=DRAW">Symbolleiste Standard</a></li>\
    <li><a target="_top" href="de/text/shared/main0213.html?DbPAR=DRAW">Symbolleiste Formular-Navigation</a></li>\
    <li><a target="_top" href="de/text/shared/main0226.html?DbPAR=DRAW">Symbolleiste Formular-Entwurf</a></li>\
    <li><a target="_top" href="de/text/shared/main0227.html?DbPAR=DRAW">Symbolleiste Punkte bearbeiten</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Laden, Speichern, Importieren und Exportieren</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/palette_files.html?DbPAR=DRAW">Laden von Farb-, Farbverlaufs- und Schraffurtabellen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafiken einfügen</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatierung</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/palette_files.html?DbPAR=DRAW">Laden von Farb-, Farbverlaufs- und Schraffurtabellen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Laden von Linienstil- und Linienspitzentabellen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/color_define.html?DbPAR=DRAW">Erstellen benutzerdefinierter Farben</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/gradient.html?DbPAR=DRAW">Erzeugen von Farbverlaufsfüllungen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Farben ersetzen mit der Pipette</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Anordnen, Ausrichten und Verteilen von Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/background.html?DbPAR=DRAW">Ändern der Hintergrundfüllung von Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/masterpage.html?DbPAR=DRAW">Ändern und Hinzufügen einer Masterfolie</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/move_object.html?DbPAR=DRAW">Verschieben von Objekten</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Drucken</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/printing.html?DbPAR=DRAW">Drucken von Präsentationen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Drucken einer an ein Papierformat angepassten Folie</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effekte</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Überblendung zwischen zwei Objekten</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objekte, Grafiken und Bitmaps</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Kombinieren von Objekten und Bilden von Formen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Sektoren und Segmente zeichnen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Objekt duplizieren</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Drehen von Objekten</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">3D-Objekte zusammensetzen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Verbinden von Linien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/text2curve.html?DbPAR=DRAW">Umwandeln von Textzeichen in Zeichnungsobjekte</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/vectorize.html?DbPAR=DRAW">Konvertieren von Bitmap-Bildern in Vektorgrafiken</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/3d_create.html?DbPAR=DRAW">Umwandeln von 2D-Objekten in Kurven, Polygone und 3D-Objekte</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Laden von Linienstil- und Linienspitzentabellen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_draw.html?DbPAR=DRAW">Beliebige Kurven zeichnen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/line_edit.html?DbPAR=DRAW">Bearbeiten von Kurven</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Grafiken einfügen</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/table_insert.html?DbPAR=DRAW">Einbinden von Tabellendokumenten in Folien</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/move_object.html?DbPAR=DRAW">Verschieben von Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/select_object.html?DbPAR=DRAW">Auswählen von darunter liegenden Objekten</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/orgchart.html?DbPAR=DRAW">Erstellen von Flussdiagrammen</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Gruppen und Ebenen</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/groups.html?DbPAR=DRAW">Gruppieren von Objekten</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/layers.html?DbPAR=DRAW">Über Ebenen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Ebene einfügen</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Mit Ebenen arbeiten</a></li>\
    <li><a target="_top" href="de/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Objekte in eine andere Ebene verschieben</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Zeichnungen</label><ul>\
    <li><a target="_top" href="de/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Hinzufügen von Text</a></li>\
    <li><a target="_top" href="de/text/simpress/guide/text2curve.html?DbPAR=DRAW">Umwandeln von Textzeichen in Zeichnungsobjekte</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Anzeigen</label><ul>\
    <li><a target="_top" href="de/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoomen mit der Tastatur</a></li>\
         </ul></li>\
     </ul></li></ul>\
';
