document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="07"><label for="07">Макросы и скрипты</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/shared/main0601.html?DbPAR=BASIC">Справка по LibreOffice Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01000000.html?DbPAR=BASIC">Программирование с помощью LibreOffice Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/00000002.html?DbPAR=BASIC">Глоссарий LibreOffice Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01010210.html?DbPAR=BASIC">Основы</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01020000.html?DbPAR=BASIC">Синтаксис</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01030100.html?DbPAR=BASIC">Общее представление об IDE</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01030200.html?DbPAR=BASIC">Редактор Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01050100.html?DbPAR=BASIC">Окно "Контрольное значение"</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/main0211.html?DbPAR=BASIC">Панель макроса</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/05060700.html?DbPAR=BASIC">Макрос</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Справочник команд</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/shared/01020300.html?DbPAR=BASIC">Использование процедур и функций</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01020500.html?DbPAR=BASIC">Библиотеки, модули и диалоговые окна</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Функции, выражения и операторы</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010000.html?DbPAR=BASIC">Функции экранного ввода/вывода</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020000.html?DbPAR=BASIC">Функции файлового ввода/вывода</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030000.html?DbPAR=BASIC">Функции даты и времени</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050000.html?DbPAR=BASIC">Функции обработки ошибок</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060000.html?DbPAR=BASIC">Логические операторы</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070000.html?DbPAR=BASIC">Математические операторы</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080000.html?DbPAR=BASIC">Числовые функции</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090000.html?DbPAR=BASIC">Управление выполнением программы</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100000.html?DbPAR=BASIC">Переменные</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03110000.html?DbPAR=BASIC">Операторы сравнения</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120000.html?DbPAR=BASIC">Строки</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130000.html?DbPAR=BASIC">Другие команды</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Алфавитный список функций, выражений и операторов</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020301.html?DbPAR=BASIC">Функция Eof</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050000.html?DbPAR=BASIC">Функции обработки ошибок</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090400.html?DbPAR=BASIC">Дополнительные инструкции</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080300.html?DbPAR=BASIC">Получение случайных чисел</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080000.html?DbPAR=BASIC">Числовые функции</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080400.html?DbPAR=BASIC">Вычисление квадратного корня</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03080100.html?DbPAR=BASIC">Тригонометрические функции</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Расширенные библиотеки Basic</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Руководства</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/macro_recording.html?DbPAR=BASIC">Запись макроса</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Изменение свойств элементов управления в редакторе диалоговых окон</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Создание элементов управления в редакторе диалоговых окон</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Примеры программирования для элементов управления в редакторе диалоговых окон</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Открытие диалога в Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Создание диалогового окна с помощью Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01030400.html?DbPAR=BASIC">Организация библиотек и модулей</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01020100.html?DbPAR=BASIC">Использование переменных</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01020200.html?DbPAR=BASIC">Использование объектов</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01030300.html?DbPAR=BASIC">Отладка программы Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/shared/01040000.html?DbPAR=BASIC">Макросы, управляемые событиями</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Примеры программирования на Basic</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="ru/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Справка по макросам на Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/python/main0000.html?DbPAR=BASIC">Python скрипты</a></li>\
    <li><a target="_top" href="ru/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE для Python</a></li>\
    <li><a target="_top" href="ru/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="ru/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Программирование на Python</label><ul>\
    <li><a target="_top" href="ru/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="ru/text/sbasic/python/python_examples.html?DbPAR=BASIC">Примеры на Python</a></li>\
    <li><a target="_top" href="ru/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Электронные таблицы (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/scalc/main0000.html?DbPAR=CALC">Справка по LibreOffice Calc</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0503.html?DbPAR=CALC">Функции LibreOffice Calc</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/keyboard.html?DbPAR=CALC">Сочетания клавиш (специальные возможности LibreOffice Calc)</a></li>\
    <li><a target="_top" href="ru/text/scalc/04/01020000.html?DbPAR=CALC">Сочетания клавиш для электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/05/02140000.html?DbPAR=CALC">Коды ошибок в LibreOffice Calc</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060112.html?DbPAR=CALC">Надстройка для программирования в LibreOffice Calc</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/main.html?DbPAR=CALC">Инструкции по использованию LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Справочник по командам и меню</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Меню</label><ul>\
    <li><a target="_top" href="ru/text/scalc/main0100.html?DbPAR=CALC">Меню</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0101.html?DbPAR=CALC">Файл</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0102.html?DbPAR=CALC">Изменить</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0103.html?DbPAR=CALC">Вид</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0104.html?DbPAR=CALC">Вставка</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0105.html?DbPAR=CALC">Формат</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0116.html?DbPAR=CALC">Лист</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0112.html?DbPAR=CALC">Данные</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0106.html?DbPAR=CALC">Сервис</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0107.html?DbPAR=CALC">Окно</a></li>\
    <li><a target="_top" href="ru/text/shared/main0108.html?DbPAR=CALC">Справка</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Панели инструментов</label><ul>\
    <li><a target="_top" href="ru/text/scalc/main0200.html?DbPAR=CALC">Панели инструментов</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0202.html?DbPAR=CALC">Панель форматирования</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0203.html?DbPAR=CALC">Панель свойств рисованного объекта</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0205.html?DbPAR=CALC">Панель форматирования текста</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0206.html?DbPAR=CALC">Панель формул</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0208.html?DbPAR=CALC">Строка состояния</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0210.html?DbPAR=CALC">Панель предварительного просмотра</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0214.html?DbPAR=CALC">Панель Изображение</a></li>\
    <li><a target="_top" href="ru/text/scalc/main0218.html?DbPAR=CALC">Главная панель инструментов</a></li>\
    <li><a target="_top" href="ru/text/shared/main0201.html?DbPAR=CALC">Стандартная панель</a></li>\
    <li><a target="_top" href="ru/text/shared/main0212.html?DbPAR=CALC">Панель таблицы данных</a></li>\
    <li><a target="_top" href="ru/text/shared/main0213.html?DbPAR=CALC">Панель "Навигатор форм"</a></li>\
    <li><a target="_top" href="ru/text/shared/main0214.html?DbPAR=CALC">Панель конструктора запросов</a></li>\
    <li><a target="_top" href="ru/text/shared/main0226.html?DbPAR=CALC">Панель инструментов конструктора форм</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Типы функций и операторы</label><ul>\
    <li><a target="_top" href="ru/text/scalc/01/04060000.html?DbPAR=CALC">Мастер функций</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060100.html?DbPAR=CALC">Функции по категориям</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060107.html?DbPAR=CALC">Функции массива</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060120.html?DbPAR=CALC">Функции для побитовых операций</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060101.html?DbPAR=CALC">Функции базы данных</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060102.html?DbPAR=CALC">Функции даты и времени</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060103.html?DbPAR=CALC">Финансовые функции (часть первая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060119.html?DbPAR=CALC">Финансовые функции (часть вторая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060118.html?DbPAR=CALC">Финансовые функции (часть третья)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060104.html?DbPAR=CALC">Функции информации</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060105.html?DbPAR=CALC">Логические функции</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060106.html?DbPAR=CALC">Математические функции</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060108.html?DbPAR=CALC">Статистические функции</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060181.html?DbPAR=CALC">Статистические функции (часть первая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060182.html?DbPAR=CALC">Статистические функции (часть вторая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060183.html?DbPAR=CALC">Статистические функции (часть третья)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060184.html?DbPAR=CALC">Статистические функции (часть четвертая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060185.html?DbPAR=CALC">Статистические функции (часть пятая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060109.html?DbPAR=CALC">Функции электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060110.html?DbPAR=CALC">Текстовые функции</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060111.html?DbPAR=CALC">Функции надстроек</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060115.html?DbPAR=CALC">Функции надстроек, список функций для анализа (часть первая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060116.html?DbPAR=CALC">Функции надстроек, список функций для анализа (часть вторая)</a></li>\
    <li><a target="_top" href="ru/text/scalc/01/04060199.html?DbPAR=CALC">Обозначение операций в формулах LibreOffice Calc</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Пользовательские функции</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Открытие, Сохранение, Импорт, Экспорт и Редактура</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/webquery.html?DbPAR=CALC">Вставка внешних данных в таблицу (веб-запрос)</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/html_doc.html?DbPAR=CALC">Сохранение и открытие листов в HTML</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/csv_formula.html?DbPAR=CALC">Импорт и экспорт текстовых файлов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Форматирование</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/text_rotate.html?DbPAR=CALC">Вращение текста</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/text_wrap.html?DbPAR=CALC">Ввод многострочного текста</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/text_numbers.html?DbPAR=CALC">Форматирование чисел как текста</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/super_subscript.html?DbPAR=CALC">Надстрочный/подстрочный текст</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/row_height.html?DbPAR=CALC">Изменение высоты строки или ширины столбца</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Применение условного форматирования</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Выделение отрицательных чисел</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Задание форматов формулой</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Ввод числа с начальными нулями</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/format_table.html?DbPAR=CALC">Форматирование электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/format_value.html?DbPAR=CALC">Форматирование чисел со знаками после запятой</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/value_with_name.html?DbPAR=CALC">Присвоение имён ячейкам</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/table_rotate.html?DbPAR=CALC">Вращение таблиц (транспонирование)</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/rename_table.html?DbPAR=CALC">Переименование листов</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx годы</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Использование округленных значений</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/currency_format.html?DbPAR=CALC">Ячейки в денежном формате</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/autoformat.html?DbPAR=CALC">Использование автоформата для таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/note_insert.html?DbPAR=CALC">Вставка и изменение комментариев</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/design.html?DbPAR=CALC">Выбор тем для листов</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Ввод простых дробей</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Фильтрация и сортировка</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/filters.html?DbPAR=CALC">Применение фильтров</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/specialfilter.html?DbPAR=CALC">Фильтр. Применение расширенных фильтров</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/autofilter.html?DbPAR=CALC">Применение автофильтра</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/sorted_list.html?DbPAR=CALC">Применение списков сортировки</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Печать</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/print_title_row.html?DbPAR=CALC">Печать строк или столбцов на каждой странице</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/print_landscape.html?DbPAR=CALC">Печать листов в альбомном формате</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/print_details.html?DbPAR=CALC">Печать параметров листа</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/print_exact.html?DbPAR=CALC">Определение числа печатаемых страниц</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Диапазоны данных</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/database_define.html?DbPAR=CALC">Определение диапазонов баз данных</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/database_filter.html?DbPAR=CALC">Фильтрация диапазонов ячеек</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/database_sort.html?DbPAR=CALC">Сортировка данных</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Сводная таблица</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot.html?DbPAR=CALC">Сводная таблица</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Создание сводных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Удаление сводных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Редактирование сводных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Фильтрация сводных таблиц</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Выбор диапазона для вывода сводной таблицы</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Обновление сводных таблиц</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Сводная диаграмма</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Сценарии</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/scenario.html?DbPAR=CALC">Использование сценариев</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Ссылки</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Адреса и ссылки, абсолютные и относительные</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellreferences.html?DbPAR=CALC">Ссылка на ячейку другого документа</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Ссылки на другие листы и ссылки на URL-адреса</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Ссылка на ячейки путём перетаскивания</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/address_auto.html?DbPAR=CALC">Распознавание имён при адресации</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Просмотр, выбор, копирование</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/table_view.html?DbPAR=CALC">Изменение представлений таблицы</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/formula_value.html?DbPAR=CALC">Отображение формул или значений</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/line_fix.html?DbPAR=CALC">Закрепление строк и столбцов в качестве заголовков</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/multi_tables.html?DbPAR=CALC">Переходы по ярлычкам листов</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Копирование нескольких листов</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cellcopy.html?DbPAR=CALC">Копирование только видимых ячеек</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/mark_cells.html?DbPAR=CALC">Выделение нескольких ячеек</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Формулы и вычисления</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/formulas.html?DbPAR=CALC">Вычисления по формулам</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/formula_copy.html?DbPAR=CALC">Копирование формул</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/formula_enter.html?DbPAR=CALC">Ввод формул</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/formula_value.html?DbPAR=CALC">Отображение формул или значений</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/calculate.html?DbPAR=CALC">Вычисления в электронных таблицах</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/calc_date.html?DbPAR=CALC">Операции с датами и временем</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/calc_series.html?DbPAR=CALC">Автоматическое вычисление рядов данных</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Вычисление разницы во времени</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/matrixformula.html?DbPAR=CALC">Ввод матричных формул</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Защита</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/cell_protect.html?DbPAR=CALC">Защита ячеек от изменений</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Снятие защиты ячеек</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Прочее</label><ul>\
    <li><a target="_top" href="ru/text/scalc/guide/auto_off.html?DbPAR=CALC">Отключение автоматических изменений</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/consolidate.html?DbPAR=CALC">Объединение данных</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/goalseek.html?DbPAR=CALC">Применение подбора параметра</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/multioperation.html?DbPAR=CALC">Использование совмещенных операций</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/multitables.html?DbPAR=CALC">Использование нескольких листов</a></li>\
    <li><a target="_top" href="ru/text/scalc/guide/validity.html?DbPAR=CALC">Проверка содержимого ячеек</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Диаграммы и схемы</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Общие сведения</label><ul>\
    <li><a target="_top" href="ru/text/schart/main0000.html?DbPAR=CHART">Диаграммы в LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/schart/main0503.html?DbPAR=CHART">Возможности диаграмм LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/schart/04/01020000.html?DbPAR=CHART">Сочетания клавиш для диаграмм</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Установка LibreOffice</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Изменение сопоставлений типов документов Microsoft Office</a></li>\
    <li><a target="_top" href="ru/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Общие разделы справки</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Общие сведения</label><ul>\
    <li><a target="_top" href="ru/text/shared/main0400.html?DbPAR=SHARED">Сочетания клавиш</a></li>\
    <li><a target="_top" href="ru/text/shared/00/00000005.html?DbPAR=SHARED">Общий глоссарий</a></li>\
    <li><a target="_top" href="ru/text/shared/00/00000002.html?DbPAR=SHARED">Глоссарий терминов Интернета</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/accessibility.html?DbPAR=SHARED">Специальные возможности в LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/keyboard.html?DbPAR=SHARED">Сочетания клавиш (специальные возможности LibreOffice)</a></li>\
    <li><a target="_top" href="ru/text/shared/04/01010000.html?DbPAR=SHARED">Общие сочетания клавиш в LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/version_number.html?DbPAR=SHARED">Номера версии и сборки</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice и Microsoft Office</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/ms_user.html?DbPAR=SHARED">Работа в Microsoft Office и LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Сравнение терминов Microsoft Office и LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">О преобразовании документов Microsoft Office</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Изменение сопоставлений типов документов Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Параметры LibreOffice</label><ul>\
    <li><a target="_top" href="ru/text/shared/optionen/01000000.html?DbPAR=SHARED">Параметры</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010100.html?DbPAR=SHARED">Сведения о пользователе</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010200.html?DbPAR=SHARED">Общие</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010300.html?DbPAR=SHARED">Пути</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010400.html?DbPAR=SHARED">Вспомогательные средства</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010600.html?DbPAR=SHARED">Общие</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010700.html?DbPAR=SHARED">Шрифты</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010800.html?DbPAR=SHARED">Вид</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01010900.html?DbPAR=SHARED">Печать</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01012000.html?DbPAR=SHARED">Внешний вид</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01013000.html?DbPAR=SHARED">Специальные возможности</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01020000.html?DbPAR=SHARED">Параметры загрузки/сохранения</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01030000.html?DbPAR=SHARED">Интернет</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01040000.html?DbPAR=SHARED">Параметры текстового документа</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01050000.html?DbPAR=SHARED">Параметры HTML-документа</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01060000.html?DbPAR=SHARED">Параметры электронной таблицы</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01070000.html?DbPAR=SHARED">Параметры презентации</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01080000.html?DbPAR=SHARED">Параметры рисунков</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01090000.html?DbPAR=SHARED">Формула</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01110000.html?DbPAR=SHARED">Диаграммы</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01130100.html?DbPAR=SHARED">Свойства VBA</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01140000.html?DbPAR=SHARED">Языки</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01150000.html?DbPAR=SHARED">Параметры настройки языка</a></li>\
    <li><a target="_top" href="ru/text/shared/optionen/01160000.html?DbPAR=SHARED">Параметры источников данных</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Мастера</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01000000.html?DbPAR=SHARED">Мастер</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Мастер писем</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01010000.html?DbPAR=SHARED">Мастер писем</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Мастер факсов</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01020000.html?DbPAR=SHARED">Мастер факсов</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Мастер повестки дня</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01040000.html?DbPAR=SHARED">Мастер повестки дня</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Мастер экспорта HTML</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01110000.html?DbPAR=SHARED">Экспорт HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Мастер конвертера документов</label><ul>\
    <li><a target="_top" href="ru/text/shared/autopi/01130000.html?DbPAR=SHARED">Преобразование документов</a></li>\
			</ul></li>\
    <li><a target="_top" href="ru/text/shared/autopi/01150000.html?DbPAR=SHARED">Мастер конвертера евро</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Настройка LibreOffice</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/configure_overview.html?DbPAR=SHARED">Настройка LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/01/packagemanager.html?DbPAR=SHARED">Управление расширениями</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/flat_icons.html?DbPAR=SHARED">Изменение вида значков</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Настройка панелей инструментов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/workfolder.html?DbPAR=SHARED">Изменение рабочего каталога</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/standard_template.html?DbPAR=SHARED">Изменение шаблонов по умолчанию</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Регистрация адресной книги</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/formfields.html?DbPAR=SHARED">Вставка и изменение кнопок</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Работа с пользовательским интерфейсом</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Быстрые переходы к объектам</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/navigator.html?DbPAR=SHARED">Общее представление о навигаторе для документов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/autohide.html?DbPAR=SHARED">Отображение, закрепление и скрытие окон</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/textmode_change.html?DbPAR=SHARED">Переключение между режимами вставки и замены</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Использование панелей инструментов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Цифровые подписи</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/digital_signatures.html?DbPAR=SHARED">О цифровых подписях</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Применение цифровых подписей</a></li>\
    <li><a target="_top" href="ru/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="ru/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="ru/text/swriter/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Text Documents</a></li>\
    <li><a target="_top" href="ru/text/swriter/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Принтеры, факсы, отправка</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/labels_database.html?DbPAR=SHARED">Печать этикеток с адресами</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Чёрно-белая печать</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/email.html?DbPAR=SHARED">Отправка документов электронной почтой</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/fax.html?DbPAR=SHARED">Отправка факсов и настройка LibreOffice для отправки факсов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Перетаскивание</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop.html?DbPAR=SHARED">Перетаскивание в документе LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Перемещение и копирование текста в документах</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Копирование областей электронной таблицы в текстовые документы</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Копирование графических объектов из документа в документ</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Копирование рисунков из галереи</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Перетаскивание в представлении источника данных</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Копирование и вставка</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Копирование рисованных объектов в другие документы</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Копирование графических объектов из документа в документ</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Копирование рисунков из галереи</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Копирование областей электронной таблицы в текстовые документы</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Диаграммы и схемы</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/chart_insert.html?DbPAR=SHARED">Вставка диаграмм</a></li>\
    <li><a target="_top" href="ru/text/schart/main0000.html?DbPAR=SHARED">Диаграммы в LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Открыть, Сохранить, Импортировать, Экспортировать, PDF</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/doc_open.html?DbPAR=SHARED">Открытие документов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/import_ms.html?DbPAR=SHARED">Открытие документов, сохраненных в других форматах</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/doc_save.html?DbPAR=SHARED">Сохранение документов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Автоматическое сохранение документов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/export_ms.html?DbPAR=SHARED">Сохранение документов в других форматах</a></li>\
    <li><a target="_top" href="ru/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Экспорт как PDF</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Импорт и экспорт данных в текстовом формате</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Связи и ссылки</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Вставка гиперссылок</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Относительные и абсолютные ссылки</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Редактирование гиперссылок</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Отслеживание версий документов</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Сравнение версий документа</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Объединение версий</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Запись изменений</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining.html?DbPAR=SHARED">Запись и отображение изменений</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Принятие и отклонение изменений</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Управление версиями</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Этикетки и визитки</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/labels.html?DbPAR=SHARED">Создание и печать этикеток и визитных карточек</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Вставка внешних данных</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/copytable2application.html?DbPAR=SHARED">Вставка данных из электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/copytext2application.html?DbPAR=SHARED">Вставка данных из текстовых документов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Вставка, редактирование, сохранение растровых изображений</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Добавление рисунков в галерею</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Автоматические функции</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Выключение автораспознавания URL-адресов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Поиск и замена</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/data_search2.html?DbPAR=SHARED">Поиск с помощью фильтра форм</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_search.html?DbPAR=SHARED">Поиск по документам таблиц и форм</a></li>\
    <li><a target="_top" href="ru/text/shared/01/02100001.html?DbPAR=SHARED">Список регулярных выражений</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Инструкции</label><ul>\
    <li><a target="_top" href="ru/text/shared/guide/linestyles.html?DbPAR=SHARED">Применение стилей линии</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/text_color.html?DbPAR=SHARED">Изменение цвета текста</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/change_title.html?DbPAR=SHARED">Изменение заголовка документа</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/round_corner.html?DbPAR=SHARED">Создание закругленных углов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/background.html?DbPAR=SHARED">Определение цвета или рисунка фона</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/lineend_define.html?DbPAR=SHARED">Определение концов линий</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Определение стилей линий</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Редактирование графических объектов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/line_intext.html?DbPAR=SHARED">Рисование линий в тексте</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/aaa_start.html?DbPAR=SHARED">Первые шаги</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Вставка объектов из галереи</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Вставка специальных символов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/tabs.html?DbPAR=SHARED">Вставка и изменение позиций табуляции</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/protection.html?DbPAR=SHARED">Защита содержимого в LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Защита записей</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Выбор оптимальной печатаемой области на странице</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/measurement_units.html?DbPAR=SHARED">Выбор единиц измерения</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/language_select.html?DbPAR=SHARED">Выбор языка документа</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Конструктор таблиц</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Отключение маркеров и нумерации для отдельных абзацев</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Функциональность баз данных (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Общие сведения</label><ul>\
    <li><a target="_top" href="ru/text/shared/explorer/database/main.html?DbPAR=SHARED">База данных LibreOffice</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/database_main.html?DbPAR=SHARED">Обзор базы данных</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_new.html?DbPAR=SHARED">Создание новой базы данных</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_tables.html?DbPAR=SHARED">Работа с таблицами</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_queries.html?DbPAR=SHARED">Работа с запросами</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_forms.html?DbPAR=SHARED">Работа с формами</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_reports.html?DbPAR=SHARED">Создание отчетов</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_register.html?DbPAR=SHARED">Регистрация и удаление базы данных</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_im_export.html?DbPAR=SHARED">Импорт и экспорт данных в базу</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/data_enter_sql.html?DbPAR=SHARED">Выполнение команд SQL</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Презентации (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/simpress/main0000.html?DbPAR=IMPRESS">Добро пожаловать в справку LibreOffice Impress</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0503.html?DbPAR=IMPRESS">Возможности LibreOffice Impress</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Использование сочетаний клавиш в LibreOffice Impress</a></li>\
    <li><a target="_top" href="ru/text/simpress/04/01020000.html?DbPAR=IMPRESS">Сочетания клавиш для LibreOffice Impress</a></li>\
    <li><a target="_top" href="ru/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/main.html?DbPAR=IMPRESS">Инструкции по использованию LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Справочник по командам и меню</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Меню</label><ul>\
    <li><a target="_top" href="ru/text/simpress/main0100.html?DbPAR=IMPRESS">Меню</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0101.html?DbPAR=IMPRESS">Файл</a></li>\
    <li><a target="_top" href="ru/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0103.html?DbPAR=IMPRESS">Вид</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0104.html?DbPAR=IMPRESS">Вставка</a></li>\
    <li><a target="_top" href="ru/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="ru/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0114.html?DbPAR=IMPRESS">Показ слайдов</a></li>\
    <li><a target="_top" href="ru/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0107.html?DbPAR=IMPRESS">Окно</a></li>\
    <li><a target="_top" href="ru/text/shared/main0108.html?DbPAR=IMPRESS">Справка</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Панели инструментов</label><ul>\
    <li><a target="_top" href="ru/text/simpress/main0200.html?DbPAR=IMPRESS">Панели инструментов</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0202.html?DbPAR=IMPRESS">Панель "Линия и заливка"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0203.html?DbPAR=IMPRESS">Панель "Форматирование текста"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0204.html?DbPAR=IMPRESS">Панель "Слайды"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0206.html?DbPAR=IMPRESS">Строка состояния</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0209.html?DbPAR=IMPRESS">Линейки</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0210.html?DbPAR=IMPRESS">Панель "Рисование"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0211.html?DbPAR=IMPRESS">Панель "Структура"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0212.html?DbPAR=IMPRESS">Панель "Сортировщик слайдов"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0213.html?DbPAR=IMPRESS">Панель "Параметры"</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0214.html?DbPAR=IMPRESS">Панель Изображение</a></li>\
    <li><a target="_top" href="ru/text/shared/main0201.html?DbPAR=IMPRESS">Стандартная панель</a></li>\
    <li><a target="_top" href="ru/text/shared/main0213.html?DbPAR=IMPRESS">Панель "Навигатор форм"</a></li>\
    <li><a target="_top" href="ru/text/shared/main0226.html?DbPAR=IMPRESS">Панель инструментов конструктора форм</a></li>\
    <li><a target="_top" href="ru/text/shared/main0227.html?DbPAR=IMPRESS">Панель изменения геометрии</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Открытие, Сохранение, Импорт, Экспорт и Редактура</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Сохранение презентации в формате HTML</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Импорт страниц HTML в презентации</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Загрузка списков цветов, градиентов и штриховок</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Экспорт анимации в формат GIF</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Вставка в слайды электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Вставка графических объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Копирование слайдов из других презентаций</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Форматирование</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Загрузка списков цветов, градиентов и штриховок</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Загрузка стилей линий и стрелок</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Определение дополнительных цветов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Создание градиентной заливки</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Замена цветов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Расположение, выравнивание и распределение объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/background.html?DbPAR=IMPRESS">Изменение заливки для фона слайда</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/footer.html?DbPAR=IMPRESS">Добавление колонтитула во все слайды</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Перемещение объектов</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Печать</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/printing.html?DbPAR=IMPRESS">Печать презентаций</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Печать слайда с настройкой по размеру бумаги</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Эффекты</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Экспорт анимации в формат GIF</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Анимированные объекты на слайдах презентации</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Анимированная смена слайдов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Затенение двух объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Создание анимированных изображений формата GIF</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Объекты, графические объекты и растровые изображения</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Комбинирование объектов и построение фигур</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Группировка объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Рисование секторов и сегментов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Дублирование объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Вращение объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Группировка трёхмерных объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Соединение линий</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Преобразование текста в рисованные объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Преобразование растровых изображений в векторные графические объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Преобразование двумерных объектов в кривые, многоугольники и трёхмерные объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Загрузка стилей линий и стрелок</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Рисование кривых</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Изменение кривых</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Вставка графических объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Вставка в слайды электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Перемещение объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Выделить скрытые объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Создание блок-схемы</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Текст в презентациях</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Добавление текста</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Преобразование текста в рисованные объекты</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Просмотр</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Изменение порядка слайдов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Изменение масштаба изображения с помощью клавиатуры</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Слайд-шоу</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/show.html?DbPAR=IMPRESS">Демонстрация</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/individual.html?DbPAR=IMPRESS">Создание настраиваемого показа слайдов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Настройка времени для смены слайдов</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Формулы (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/smath/main0000.html?DbPAR=MATH">Добро пожаловать в справку приложения LibreOffice Math</a></li>\
    <li><a target="_top" href="ru/text/smath/main0503.html?DbPAR=MATH">Возможности приложения LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Элементы формулы LibreOffice</label><ul>\
    <li><a target="_top" href="ru/text/smath/01/03090100.html?DbPAR=MATH">Унарные/бинарные операторы</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090200.html?DbPAR=MATH">Отношения</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090800.html?DbPAR=MATH">Операции над множествами</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090400.html?DbPAR=MATH">Функции</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090300.html?DbPAR=MATH">Операторы</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090600.html?DbPAR=MATH">Атрибуты</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090500.html?DbPAR=MATH">Скобки</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03090700.html?DbPAR=MATH">Формат</a></li>\
    <li><a target="_top" href="ru/text/smath/01/03091600.html?DbPAR=MATH">Другие символы</a></li>\
            </ul></li>\
    <li><a target="_top" href="ru/text/smath/guide/main.html?DbPAR=MATH">Инструкции по использованию LibreOffice Math</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/keyboard.html?DbPAR=MATH">Ярлыки (специальные возможности LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Справочник по командам и меню</label><ul>\
    <li><a target="_top" href="ru/text/smath/main0100.html?DbPAR=MATH">Меню</a></li>\
    <li><a target="_top" href="ru/text/smath/main0200.html?DbPAR=MATH">Панели инструментов</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Работа с формулами</label><ul>\
    <li><a target="_top" href="ru/text/smath/guide/align.html?DbPAR=MATH">Выравнивание частей формулы вручную</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/attributes.html?DbPAR=MATH">Изменение значений атрибутов по умолчанию</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/brackets.html?DbPAR=MATH">Объединение частей формулы с помощью скобок</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/comment.html?DbPAR=MATH">Ввод комментариев</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/newline.html?DbPAR=MATH">Ввод разрывов строки</a></li>\
    <li><a target="_top" href="ru/text/smath/guide/parentheses.html?DbPAR=MATH">Вставка скобок</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="02"><label for="02">Текстовые документы (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/swriter/main0000.html?DbPAR=WRITER">Добро пожаловать в справку приложения LibreOffice Writer</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0503.html?DbPAR=WRITER">Возможности приложения LibreOffice Writer</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/main.html?DbPAR=WRITER">Инструкции по работе с LibreOffice Writer</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Закрепление окон и изменение их размера</a></li>\
    <li><a target="_top" href="ru/text/swriter/04/01020000.html?DbPAR=WRITER">Сочетания клавиш для LibreOffice Writer</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/words_count.html?DbPAR=WRITER">Подсчёт слов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/keyboard.html?DbPAR=WRITER">Использование сочетаний клавиш (специальные возможности LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Справочник по командам и меню</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Меню</label><ul>\
    <li><a target="_top" href="ru/text/swriter/main0100.html?DbPAR=WRITER">Меню</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0101.html?DbPAR=WRITER">Файл</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0102.html?DbPAR=WRITER">Правка</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0103.html?DbPAR=WRITER">Вид</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0104.html?DbPAR=WRITER">Вставка</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0105.html?DbPAR=WRITER">Формат</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0115.html?DbPAR=WRITER">Styles</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0110.html?DbPAR=WRITER">Таблица</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0106.html?DbPAR=WRITER">Сервис</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0107.html?DbPAR=WRITER">Окно</a></li>\
    <li><a target="_top" href="ru/text/shared/main0108.html?DbPAR=WRITER">Справка</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Панели инструментов</label><ul>\
    <li><a target="_top" href="ru/text/swriter/main0200.html?DbPAR=WRITER">Панели инструментов</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0202.html?DbPAR=WRITER">Панель форматирования</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0203.html?DbPAR=WRITER">Image Bar</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0204.html?DbPAR=WRITER">Панель таблицы</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0205.html?DbPAR=WRITER">Панель свойств рисованного объекта</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0206.html?DbPAR=WRITER">Панель "Маркеры и нумерация"</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0208.html?DbPAR=WRITER">Строка состояния</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0210.html?DbPAR=WRITER">Print Preview</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0213.html?DbPAR=WRITER">Линейки</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0214.html?DbPAR=WRITER">Панель формул</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0215.html?DbPAR=WRITER">Панель врезки</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0216.html?DbPAR=WRITER">Панель объектов OLE</a></li>\
    <li><a target="_top" href="ru/text/swriter/main0220.html?DbPAR=WRITER">Панель текстового объекта</a></li>\
    <li><a target="_top" href="ru/text/shared/main0201.html?DbPAR=WRITER">Стандартная панель</a></li>\
    <li><a target="_top" href="ru/text/shared/main0212.html?DbPAR=WRITER">Панель таблицы данных</a></li>\
    <li><a target="_top" href="ru/text/shared/main0213.html?DbPAR=WRITER">Панель "Навигатор форм"</a></li>\
    <li><a target="_top" href="ru/text/shared/main0214.html?DbPAR=WRITER">Панель конструктора запросов</a></li>\
    <li><a target="_top" href="ru/text/shared/main0226.html?DbPAR=WRITER">Панель инструментов конструктора форм</a></li>\
    <li><a target="_top" href="ru/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo Toolbar</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Создание текстовых документов</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Перемещение и выделение с помощью клавиатуры</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Использование свободного ввода</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Графические объекты в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Вставка графических объектов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Вставка графического объекта из файла</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Вставка графического объекта из галереи путём перетаскивания</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Вставка сканированного изображения</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Вставка диаграммы Calc в текстовый документ</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Вставка графического объекта из LibreOffice Draw или Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Таблицы в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Включение и выключение распознавания чисел в таблицах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/tablemode.html?DbPAR=WRITER">Изменение строк и столбцов с помощью клавиатуры</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/table_delete.html?DbPAR=WRITER">Удаление таблиц или содержимого таблиц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/table_insert.html?DbPAR=WRITER">Вставка таблиц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Повторение заголовка таблицы на новой странице</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Изменение размера строк и столбцов в текстовой таблице</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Объекты в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Задание положения объектов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/wrap.html?DbPAR=WRITER">Обтекание текста вокруг объектов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Разделы и врезки в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/sections.html?DbPAR=WRITER">Использование разделов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/section_edit.html?DbPAR=WRITER">Редактирование разделов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/section_insert.html?DbPAR=WRITER">Вставка разделов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Оглавление и указатели</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Пользовательские указатели</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Создание оглавления</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_index.html?DbPAR=WRITER">Создание алфавитных указателей</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Указатели, охватывающие несколько документов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Создание библиографии</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Правка и удаление элементов указателей и оглавлений</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Обновление, изменение и удаление указателей и оглавлений</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Определение элементов указателей и оглавлений</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/indices_form.html?DbPAR=WRITER">Форматирование указателей и оглавлений</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Поля в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/fields.html?DbPAR=WRITER">Поля</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/fields_date.html?DbPAR=WRITER">Вставка фиксированного или изменяемого поля даты</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/field_convert.html?DbPAR=WRITER">Преобразование поля в текст</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Навигация в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Перемещение и копирование текста в документах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Изменение структуры документа с помощью навигатора</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Вставка гиперссылок с помощью навигатора</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/navigator.html?DbPAR=WRITER">Навигатор для текстовых документов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Вычисления в текстовых документах</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Вычисления по нескольким таблицам</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate.html?DbPAR=WRITER">Вычисления в текстовых документах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Вычисление формулы и вставка результата в текстовый документ</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Вычисление сумм для ячеек в таблицах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Вычисления по сложным формулам в текстовых документах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Отображение результатов вычисления в другой таблице</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Форматирование текстовых документов</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Шаблоны и стили</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Шаблоны и стили</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Чередование стилей страницы на нечётных и чётных страницах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/change_header.html?DbPAR=WRITER">Создание стиля страницы по образцу текущей страницы</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/load_styles.html?DbPAR=WRITER">Использование стилей из другого документа или шаблона</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Создание новых стилей на основе выделенных фрагментов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Обновление стилей на основе выделенных фрагментов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/template_create.html?DbPAR=WRITER">Создание шаблона документа</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/template_default.html?DbPAR=WRITER">Изменение шаблона по умолчанию</a></li>\
			</ul></li>\
    <li><a target="_top" href="ru/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Изменение ориентации страницы (альбомная или книжная)</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_capital.html?DbPAR=WRITER">Изменение регистра текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Скрытие текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Определение разных верхних и нижних колонтитулов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Вставка названия и номера главы в верхний или нижний колонтитул</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Применение форматирования текста при вводе</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/reset_format.html?DbPAR=WRITER">Восстановление атрибутов шрифта</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Применение стилей в режиме заполнения форматов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/wrap.html?DbPAR=WRITER">Обтекание текста вокруг объектов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Использование врезки для выравнивания текста по центру страницы</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Выделение текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Вращение текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/page_break.html?DbPAR=WRITER">Вставка и удаление разрывов страниц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Создание и применение стилей страниц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/subscript.html?DbPAR=WRITER">Преобразование текста в надстрочный или подстрочный</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Специальные элементы текста</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/captions.html?DbPAR=WRITER">Использование названий</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Условный текст</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Условный текст для количества страниц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/fields_date.html?DbPAR=WRITER">Вставка фиксированного или изменяемого поля даты</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Добавление полей ввода</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Вставка номеров последующих страниц</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Вставка номеров страниц в нижние колонтитулы</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Скрытие текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Определение разных верхних и нижних колонтитулов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Вставка названия и номера главы в верхний или нижний колонтитул</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Запросы данных пользователя в полях и условиях</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Вставка и редактирование сносок и концевых сносок</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Интервалы между сносками</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_footer.html?DbPAR=WRITER">Верхние и нижние колонтитулы</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Форматирование колонтитулов</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/text_animation.html?DbPAR=WRITER">Анимирование текста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Создание стандартного письма</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Автоматические функции</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Добавление исключений в список автозамены</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/autotext.html?DbPAR=WRITER">Использование автотекста</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Создание нумерованных и маркированных списков при вводе</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/auto_off.html?DbPAR=WRITER">Выключение Автозамены</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Автоматическая проверка орфографии</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Включение и выключение распознавания чисел в таблицах</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Расстановка переносов</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Нумерация и списки</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Добавление номеров глав к названиям</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Создание нумерованных и маркированных списков при вводе</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Объединение нумерованных списков</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Добавление номеров строк</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Изменение нумерации в нумерованном списке</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Определение диапазонов нумерации</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Добавление нумерации</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Нумерация и стили нумерации</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Добавление маркеров</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Проверка орфографии, тезаурус и языки</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Автоматическая проверка орфографии</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Удаление слов из словаря пользователя</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Тезаурус</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Проверка орфографии и грамматики</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Советы по устранению неполадок</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Вставка текста перед таблицей в начале страницы</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Переход к определенной закладке</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Открытие, Сохранение, Импорт, Экспорт и Редактура</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/send2html.html?DbPAR=WRITER">Сохранение текстовых документов в формате HTML</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Вставка целого текстового документа</a></li>\
    <li><a target="_top" href="ru/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Составные документы</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Составные документы и вложенные документы</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Связи и ссылки</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/references.html?DbPAR=WRITER">Вставка перекрестных ссылок</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Вставка гиперссылок с помощью навигатора</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Печать</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Выбор источника подачи бумаги при печати</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/print_preview.html?DbPAR=WRITER">Предварительный просмотр страницы перед печатью</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/print_small.html?DbPAR=WRITER">Печать нескольких страниц на одном листе</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Создание и применение стилей страниц</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Поиск и замена</label><ul>\
    <li><a target="_top" href="ru/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="ru/text/shared/01/02100001.html?DbPAR=WRITER">Список регулярных выражений</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML документы (Writer Web)</label><ul>\
    <li><a target="_top" href="ru/text/shared/07/09000000.html?DbPAR=WRITER">Веб-страницы</a></li>\
    <li><a target="_top" href="ru/text/shared/02/01170700.html?DbPAR=WRITER">Фильтры и формы HTML</a></li>\
    <li><a target="_top" href="ru/text/swriter/guide/send2html.html?DbPAR=WRITER">Сохранение текстовых документов в формате HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Рисование (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Общие сведения и пользовательский интерфейс</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/main0000.html?DbPAR=DRAW">Добро пожаловать в справку LibreOffice Draw</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main0503.html?DbPAR=DRAW">Возможности LibreOffice Draw</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Сочетания клавиш для рисованных объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/04/01020000.html?DbPAR=DRAW">Сочетания клавиш для рисунков</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/main.html?DbPAR=DRAW">Инструкции по использованию LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Справочник по командам и меню</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Меню</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/main0100.html?DbPAR=DRAW">Меню</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main0101.html?DbPAR=DRAW">Файл</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main0103.html?DbPAR=DRAW">Вид</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="ru/text/simpress/main0107.html?DbPAR=DRAW">Окно</a></li>\
    <li><a target="_top" href="ru/text/shared/main0108.html?DbPAR=DRAW">Справка</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Панели инструментов</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/main0200.html?DbPAR=DRAW">Панели инструментов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main0210.html?DbPAR=DRAW">Панель инструментов рисования</a></li>\
    <li><a target="_top" href="ru/text/sdraw/main0213.html?DbPAR=DRAW">Панель "Параметры"</a></li>\
    <li><a target="_top" href="ru/text/shared/main0201.html?DbPAR=DRAW">Стандартная панель</a></li>\
    <li><a target="_top" href="ru/text/shared/main0213.html?DbPAR=DRAW">Панель "Навигатор форм"</a></li>\
    <li><a target="_top" href="ru/text/shared/main0226.html?DbPAR=DRAW">Панель инструментов конструктора форм</a></li>\
    <li><a target="_top" href="ru/text/shared/main0227.html?DbPAR=DRAW">Панель изменения геометрии</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Загрузка, сохранение, импорт и экспорт</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/palette_files.html?DbPAR=DRAW">Загрузка списков цветов, градиентов и штриховок</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Вставка графических объектов</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Форматирование</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/palette_files.html?DbPAR=DRAW">Загрузка списков цветов, градиентов и штриховок</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Загрузка стилей линий и стрелок</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/color_define.html?DbPAR=DRAW">Определение дополнительных цветов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/gradient.html?DbPAR=DRAW">Создание градиентной заливки</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Замена цветов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Расположение, выравнивание и распределение объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/background.html?DbPAR=DRAW">Изменение заливки для фона слайда</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/move_object.html?DbPAR=DRAW">Перемещение объектов</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Печать</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/printing.html?DbPAR=DRAW">Печать презентаций</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Печать слайда с настройкой по размеру бумаги</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Эффекты</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Затенение двух объектов</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Объекты, графические объекты и растровые изображения</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Комбинирование объектов и построение фигур</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Рисование секторов и сегментов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Дублирование объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Вращение объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Группировка трёхмерных объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Соединение линий</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/text2curve.html?DbPAR=DRAW">Преобразование текста в рисованные объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/vectorize.html?DbPAR=DRAW">Преобразование растровых изображений в векторные графические объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/3d_create.html?DbPAR=DRAW">Преобразование двумерных объектов в кривые, многоугольники и трёхмерные объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Загрузка стилей линий и стрелок</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_draw.html?DbPAR=DRAW">Рисование кривых</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/line_edit.html?DbPAR=DRAW">Изменение кривых</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Вставка графических объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/table_insert.html?DbPAR=DRAW">Вставка в слайды электронных таблиц</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/move_object.html?DbPAR=DRAW">Перемещение объектов</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/select_object.html?DbPAR=DRAW">Выделить скрытые объекты</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/orgchart.html?DbPAR=DRAW">Создание блок-схемы</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Группы и слои</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/groups.html?DbPAR=DRAW">Группировка объектов</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="ru/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Текст в рисунках</label><ul>\
    <li><a target="_top" href="ru/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Добавление текста</a></li>\
    <li><a target="_top" href="ru/text/simpress/guide/text2curve.html?DbPAR=DRAW">Преобразование текста в рисованные объекты</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Просмотр</label><ul>\
    <li><a target="_top" href="ru/text/simpress/guide/change_scale.html?DbPAR=DRAW">Изменение масштаба изображения с помощью клавиатуры</a></li>\
         </ul></li>\
     </ul></li></ul>\
';
